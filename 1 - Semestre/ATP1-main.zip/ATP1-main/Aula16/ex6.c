#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
/*6) Faça uma função denominada tamanho receber uma string e devolver a
quantidade de caracteres da frase*/

int contador_string(char palavra[100], int cont, int espaco){

    if(palavra[cont] == '\n' || palavra[cont] == ' '){
        if(palavra[cont] == '\n'){
            return cont-espaco;
        }
        else{
            return contador_string(palavra, cont+1, espaco+1);
        }
    }
    else{
        return contador_string(palavra, cont+1, espaco);
    }
}
int main(){
    char frase[100];

    printf("Entre com a palavra: ");
    fgets(frase, 100, stdin);
    
    printf("A quantidade de caracteres da frase e: %d", contador_string(frase, 0, 0));

    return 0;
}