#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
/*1) Faça funções para calcular a soma, subtração, multiplicação e divisão de dois
números. Desenvolva uma função para cada operação. Leia dois valores do
usuário e exiba o resultado das quatro operações na main após chamar funções
desenvolvidas.*/
double soma(int n1, int n2){
    double calc;
    
    calc = (double)n1+n2;

    return calc;
}

double sub(int n1, int n2){
    double calc;

    calc = (double)n1-n2;

    return calc;
}

double multi(int n1, int n2){
    double calc;

    calc = (double)n1*n2;

    return calc;
}

double divi(int n1, int n2){
    double calc;

    calc = (double)n1/n2;

    return calc;
}

int main(){
    
    int a,b;
    
    printf("Entre com o primeiro numero: ");
    scanf("%d", &a);
    printf("Entre com o segundo numero: ");
    scanf("%d", &b);

    printf("a soma e: %lf", soma(a,b));
    printf("\na subtracao e: %lf", sub(a,b));
    printf("\na mutliplicacao e: %lf", multi(a,b));
    printf("\na divisao e: %lf", divi(a,b));

    return 0;
}