#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
/*10) Faça uma função denominada digito que recebe uma string e verificar se ela
contém somente dígitos. Se a string for composta somente por dígitos a função
retorna 1 (verdadeiro), caso contrário, a função retorna 0 (falso). Exemplo:
Digite uma palavra: 12a3
Verificação: 0
Digite uma palavra: 123
Verificação: 1*/

int verifica_digitos(char frase[100]){
    int i,j,validar=0,cont=1;
    

    for(i=0;i<strlen(frase);i++){
        for(j=0;j<10;j++){
            char n[2];
            itoa(j, n, 10);

            if(frase[i] == n[0]){
                validar = 1;
            }

        }
        if(validar != 1){
            cont = 0;
        }
        validar = 0;
    }
    
    return cont;
}

int main(){
    
    char frase[100];

    printf("Entre com a palavra: ");
    scanf("%s", frase);

    printf("Verificacao: %d", verifica_digitos(frase));
    
    return 0;
}