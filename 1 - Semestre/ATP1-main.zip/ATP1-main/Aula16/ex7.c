#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
/*7) Faça uma função denominada maiusculo para receber uma string e converter
seus caracteres para maiúsculo. Exemplo:
Digite frase: Papagaio
Frase alterada: PAPAGAIO*/
char maiusculo(char p1[100]){
    int cont;
    for(cont=0;cont<strlen(p1);cont++){
        if(p1[cont] > 96){
            printf("%c", p1[cont]-32);
        }
        else{
            printf("%c", p1[cont]);
        }
    }
    return p1;
}
int main(){
    char p1[100];

    printf("Entre com a palavra: ");
    scanf("%s", p1);
    printf("Palavra totalmente em maiusculo: %s", maiusculo(p1));
    
    
    return 0;
}