#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
/*3) Faça uma função para calcular o fatorial de um número e retornar o valor do
fatorial.*/

int fatorial(int n);

int main(){
    
    int numero;

    printf("Entre com o numero: ");
    scanf("%d", &numero);

    printf("O valor do fatorial do numero e: %d", fatorial(numero));
    
    return 0;
}

int fatorial(int n){

    if(n == 1){
        return n;
    }
    return n*fatorial(n-1);
}