#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
/*9) Faça uma função denominada remover_espacos para receber uma string e
remover espaços desnecessários, ou seja, considerar somente um espaço entre as
palavras da string. Exemplo:
Digite uma frase: hoje choveu bastante
Frase alterada: hoje choveu bastante
*/

void remover_espacos(char p[100]){
    int cont=0,i;

    for(i=0;i<strlen(p);i++){
        if(p[i] == ' ' && i != 0){
            cont++;
            if(cont == 1){
                printf(" ");
            }
        }
        else{
            cont=0;
            printf("%c", p[i]);
        }
    }
 
}

int main(){
    
    char palavra[100];

    printf("Entre com a palavra: ");
    fgets(palavra,100,stdin);

    printf("Palavra corrigida devidamente: ");
    remover_espacos(palavra);
    
    return 0;
}