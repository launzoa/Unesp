#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
/*2) Faça uma função para receber um número e exibir a tabuada desse número. A
exibição ocorrerá dentro da própria função.*/


int tabuada_recursao(int n, int cont, int tamanho){

    if(cont == tamanho){
        return printf("%d x %d = %d", n, cont, n*cont);
    }
    else{
        printf("%d x %d = %d\n", n, cont, n*cont);
        return tabuada_recursao(n, cont+1, tamanho);
    }
    
}

int main(){
    
    int numero,tamanho,contador=1;

    printf("Entre com o numero da tabuada: ");
    scanf("%d", &numero);
    printf("Entre com o tamanho da tabuada: ");
    scanf("%d", &tamanho);

    tabuada_recursao(numero, contador, tamanho);
    return 0;
}