#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
/*4) Faça uma função para receber um valor e um intervalo. A função deverá
retornar 0 (falso) se o valor não estiver no intervalo ou 1 (verdadeiro) se o valor
estiver dentro do intervalo. O intervalo é especificado por um valor inicial e final.
Exemplo de assinatura da função:
int dentro_intervalo(int valor, int inicio, int fim);
Utilize essa função em três exemplos para validar:
a) Entrada de dados para os meses do ano (1 a 12)
b) Entrada de dados de hora (0 a 23) e minutos (0 a 59)
c) Menor de idade (0 a 17)*/
int dentro_intervalo(int valor, int inicio, int fim);

int main(){
    
    int valor, inicio, fim;

    printf("Entre com o valor: ");
    scanf("%d", &valor);  
    printf("Entre com o inicio do intervalo: ");
    scanf("%d", &inicio); 
    printf("Entre com o final do intervalo: ");
    scanf("%d", &fim);   

    printf("%d", dentro_intervalo(valor,inicio,fim));

    if(dentro_intervalo(valor,inicio,fim) == 1){
        printf("O numero esta dentro do intervalo!");
    }
    else{
        printf("O numero nao esta presente no intervalo!");
    }
    return 0;
}

int dentro_intervalo(int valor, int inicio, int fim){
    int metade;
    metade = fim/2;
    while(true){
        
        if(metade == valor){
            return 1;
        }
        else{
            if(metade == inicio || metade == fim){
                return 0;
            }
            if(valor > metade){
                inicio = metade;
                metade += metade/2;
            }
            else{
                fim = metade;
                metade -= metade/2;
            }
        }
    }
}