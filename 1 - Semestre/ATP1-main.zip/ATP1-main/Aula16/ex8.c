#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
/*8) Faça uma função denominada centralizar que recebe uma string e insere
espaços no início da string de modo que a exibição da string seja centralizado.
Para tanto, além da string, também deve ser passado como parâmetro a quantidade
de caracteres que devem ser considerados para a centralização. Exemplo:
Forneça 5 palavras:
Camelo
Abacate
Rato
Computador
Laranja
Palavras Centralizadas:
Camelo
Abacate
Rato
Computador
Laranja*/

char centralizado(char p[100], int espacos){
    int i;
    for(i=0;i<espacos;i++){
        printf(" ");
    }

    printf("%s\n", p);
}

int main(){
    char palavras[5][100];
    int cont,maior=0, espacamento;

    for(cont=0;cont<5;cont++){
        printf("Entre com a palavra: ");
        scanf("%s", palavras[cont]);
    }

    maior = strlen(palavras[0]);
    for(cont=1;cont<5;cont++){
        if(strlen(palavras[cont]) > maior){
            maior = strlen(palavras[cont]);
        }
    }
    
    for(cont=0;cont<5;cont++){
        espacamento = (maior-strlen(palavras[cont]))/2;
        centralizado(palavras[cont], espacamento);
    }
    
    return 0;
}