#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
/*5) Faça uma função denominada menu para exibir um menu para o Exercício 1.
A função deverá exibir um menu e retornar o valor da opção escolhida pelo
usuário. A exibição e leitura pode ser realizada dentro da função menu. Exemplo
de menu:
1 – Soma
2 – Subtração
3 – Multiplicação
4 – Divisão
5 – Sair
Digite opção:*/

int menu(){
    int n;
    printf("1 Soma\n2 Subtracao\n3 Multiplicacao\n4 Divisao\n5 Sair");
    printf("\nEscolha a opcao desejada: ");
    scanf("%d", &n);
    return n;
}

double soma(int n1, int n2){
    double calc;
    
    calc = (double)n1+n2;

    return calc;
}

double sub(int n1, int n2){
    double calc;

    calc = (double)n1-n2;

    return calc;
}

double multi(int n1, int n2){
    double calc;

    calc = (double)n1*n2;

    return calc;
}

double divi(int n1, int n2){
    double calc;

    calc = (double)n1/n2;

    return calc;
}

int main(){
    
    if(menu() == 5){
        printf("FIM");
    }
    else{
        int a,b;
        
        printf("Entre com o primeiro numero: ");
        scanf("%d", &a);
        printf("Entre com o segundo numero: ");
        scanf("%d", &b);

        printf("a soma e: %lf", soma(a,b));
        printf("\na subtracao e: %lf", sub(a,b));
        printf("\na mutliplicacao e: %lf", multi(a,b));
        printf("\na divisao e: %lf", divi(a,b));
    }
    return 0;
}
