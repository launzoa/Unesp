#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
/*8) Leia N números inteiros e armazene-os em um vetor. O valor de N é fornecido
pelo usuário. Em seguida, imprima os elementos que são primos e suas respectivas
posições no vetor.*/
int main(){

    int n,cont;

    printf("Entre com a quantidade de numeros a ler: ");
    scanf("%d", &n);

    int vetor[n];

    printf("Entre com os valores: \n");

    for(cont=0;cont<n;cont++){
        printf("Numero %d: ", cont+1);
        scanf("%d", &vetor[cont]);

        vetor[cont] = ((vetor[cont]%2) != 0 && vetor[cont] != 2) ? vetor[cont] : 0;
    }

    printf("O resultado:\n");

    for(cont=0;cont<n;cont++){
        if(vetor[cont] != 0){
            printf("A posicao do primo e o numero: '%d' e '%d'\n", cont, vetor[cont]);
        }
    }

    return 0;

}