#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
/*6) Faça um programa para ler N números e armazena-los em um vetor. O valor
de N é fornecido pelo usuário. Em seguida, o usuário fornecerá um número N1 e
outro número N2. Seu programa deve substituir a ocorrência de N1 por N2 no
vetor. Por exemplo:
Lista digitada: 4 5 6 7 3 5 2 3 6
N1: 3
N2: 5
Lista alterada: 4 5 6 7 5 5 2 5 6*/
int main(){

    int qntd,cont,n,m;

    printf("Entre com a quantidade de elementos: ");
    scanf("%d", &qntd);

    int vetor[qntd];

    printf("Entre com a lista de numeros: ");
    for(cont=0;cont<qntd;cont++){
        scanf("%d", &vetor[cont]);
    }
    printf("Entre com os dois numero a ser escolhido e trocado: ");
    scanf("%d%d", &n, &m);
    
    for(cont=0;cont<qntd;cont++){
        if(vetor[cont] == n){
            vetor[cont] = m;
            break;
        }
    }
    printf("A lista modificada: \n");
    for(cont=0;cont<qntd;cont++){
        printf("%d ", vetor[cont]);
    }
    return 0;

}