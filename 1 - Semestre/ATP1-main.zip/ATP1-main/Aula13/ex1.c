#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
/*1) Faça um programa para ler 5 números e armazena-los em um vetor. Em
seguida, o seu programa deverá exibir os números lidos.*/
int main(){
    int cont,vetor[5];

    printf("Entre com o valor dos numeros: \n");

    for(cont=0;cont<5;cont++){
        printf("Numero %d: ", cont+1);
        scanf("%d", &vetor[cont]);
    }   
    printf("\nO valor dos numeros:");
    for(cont=0;cont<5;cont++){
        printf("\n%d", vetor[cont]);
    }
    
    return 0;

}