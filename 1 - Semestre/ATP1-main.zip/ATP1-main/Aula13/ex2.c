#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
/*2) Faça um programa para ler N números e armazena-los em um vetor. O valor
de N é fornecido pelo usuário. Em seguida, o seu programa deverá exibir os
números lidos.*/
int main(){

    int n,cont;

    printf("Entre com a quantidade de numeros a ler: ");
    scanf("%d", &n);

    int vetor[n];

    printf("Entre com os valores: \n");

    for(cont=0;cont<n;cont++){
        printf("Numero %d: ", cont+1);
        scanf("%d", &vetor[cont]);
    }

    printf("O resultado:\n");

    for(cont=0;cont<n;cont++){
        printf("Numero %d: %d\n", cont+1, vetor[cont]);
    }

    return 0;

}