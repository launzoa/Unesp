#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
/*7) Faça um programa para gerar N números aleatórios entre 0 e 5, os quais
representam os lançamentos de um dado não viciado. Em seguida, o seu programa
deverá apresentar um relatório sobre a quantidade de ocorrências de cada face do
dado.*/
int main(){

    int cont,n,p0=0,p1=0,p2=0,p3=0,p4=0,p5=0;

    printf("Entre com a quatidade de testes: ");
    scanf("%d", &n);
    printf("Os numeros sorteados do dado:\n");
    int vetor[n];
    srand(time(NULL));

    for(cont=0;cont<n;cont++){
        vetor[cont] = rand() % 6;
        
        p0 += (vetor[cont] == 0) ? 1 : 0;
        p1 += (vetor[cont] == 1) ? 1 : 0;
        p2 += (vetor[cont] == 2) ? 1 : 0;
        p3 += (vetor[cont] == 3) ? 1 : 0;
        p4 += (vetor[cont] == 4) ? 1 : 0;
        p5 += (vetor[cont] == 5) ? 1 : 0;

        printf("%d ", vetor[cont]);
    }
    
    printf("\nA porcentagem para cada valor do dado de 0 a 5 e: \n");
    printf("Porcentagem do dado 0 : %.0f\n", ((float) p0/n)*100);
    printf("Porcentagem do dado 1 : %.0f\n", ((float) p1/n)*100);
    printf("Porcentagem do dado 2 : %.0f\n", ((float) p2/n)*100);
    printf("Porcentagem do dado 3 : %.0f\n", ((float) p3/n)*100);
    printf("Porcentagem do dado 4 : %.0f\n", ((float) p4/n)*100);
    printf("Porcentagem do dado 5 : %.0f\n", ((float) p5/n)*100);

    
    return 0;

}