#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

/*9) Faça um programa para ler 10 números DIFERENTES a serem armazenados
em um vetor. Os números deverão ser armazenados no vetor na ordem que forem
lidos, sendo que caso o usuário digite um número que já foi digitado
anteriormente, o programa deverá pedir para o usuário digitar outro número. Note
que cada valor digitado pelo usuário deve ser pesquisado no vetor, verificando se
ele existe entre os números que já foram fornecidos. Exibir na tela o vetor final
que foi digitado, o qual não terá repetição de valores.*/
int main(){

    int vetor[10],i,j,n,m;
    bool key = true;

    for(i=0;i<10;i++){
        vetor[i] = 0;
    }
    i = 0;
    while(key){
        printf("Entre com o valor: ");
        scanf("%d", &n);
        for(j=0;j<10;j++){
            m = (vetor[j] != n) ? 1 : 0;
            if(m == 0){
                break;
            }
        }
       if(m==1){
        vetor[i] = n;
        i++;
       }
       if(i == 10){
            key = false;
       }
    }

    printf("\nSaida da lista -\n");
    for(i=0;i<10;i++){
        printf("%d ", vetor[i]);
    }

    return 0;

}