#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
/*5) Faça um programa para ler N números e armazena-los em um vetor. O valor
de N é fornecido pelo usuário. Em seguida, o usuário fornecerá um número. Seu
programa deve verificar se esse número está na lista de valores digitados pelo
usuário, ou seja, verificar se esse valor está no vetor. Por exemplo:
Lista digitada: 4 5 6 7 3 5 2 3 6
Número: 3
O número 3 está no vetor
Lista digitada: 4 5 6 7 3 5 2 3 6
Número: 9
O número 9 não está no vetor*/
int main(){

    int qntd,cont,n,m=0;

    printf("Entre com a quantidade de elementos: ");
    scanf("%d", &qntd);

    int vetor[qntd];

    printf("Entre com a lista de numeros: ");
    for(cont=0;cont<qntd;cont++){
        scanf("%d", &vetor[cont]);
    }

    printf("Entre com o numero a ser escolhido: ");
    scanf("%d", &n);

    for(cont=0;cont<qntd;cont++){
        if(vetor[cont] == n){
            m=1;
            break;
        }
    }
    if(m==1){
        printf("O numero %d faz parte da lista", n);
    }
    else{
        printf("O numero %d nao faz parte da lista", n);
    }
    return 0;

}