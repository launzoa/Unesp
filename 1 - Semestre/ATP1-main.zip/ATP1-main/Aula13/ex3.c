#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

/*3) Faça um programa para ler número inteiros positivos até que um número menor
ou igual a zero seja digitado. Esses valores devem ser armazenados em um vetor.
Após a leitura, seu programa deverá percorrer o vetor para encontrar o maior
elemento, exibir o vetor e o maior elemento.*/
int main(){

    int n=1,vetor[1000],cont=0;
    bool key=true;

    printf("Entrada: \n");
    while(key){
        printf("Numero '%d': ", cont+1);
        scanf("%d", &vetor[cont]);
        if(vetor[cont] > 0){
            cont++;
            n++;
        }
        else{
            n--;
            key=false;
        }
    }
    printf("\nSaida: \n");
    for(cont=0;cont<n;cont++){
        printf("Numero '%d': %d\n", cont+1, vetor[cont]);
    }
    return 0;
}