#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
/*4) Faça um programa para ler N números e armazena-los em um vetor. O valor
de N é fornecido pelo usuário. Em seguida, imprima o vetor na ordem inversa.*/
int main(){

    int n,cont,i=1;

    printf("Entre com a quantidade de valores a ler: ");
    scanf("%d", &n);

    int vetor[n];

    printf("Entre com os valores: \n");

    for(cont=0;cont<n;cont++){
        printf("Numero %d: ", cont+1);
        scanf("%d", &vetor[cont]);
    }

    printf("O resultado:\n");

    for(cont=n-1;cont>=0;cont--){
        printf("Numero %d: %d\n", i, vetor[cont]);
        i++;
    }

    return 0;

}