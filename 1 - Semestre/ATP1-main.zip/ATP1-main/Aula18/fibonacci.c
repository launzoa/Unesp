#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

int fibonacci(int n){

    if(n < 2){
        return n;
    }
    else{
        return fibonacci(n-1)+fibonacci(n-2);
    }
}

int main(){
    int n;

    printf("Entre com o numero da sequencia: ");
    scanf("%d", &n);
    printf("%d", fibonacci(n));
    return 0;
}