#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

int fatorial(int n){

    if(n < 2){
        return 1;
    }
    else{
        return n*fatorial(n-1);
    }
}

int main(){
    
    printf("%d", fatorial(5));
    
    return 0;
}