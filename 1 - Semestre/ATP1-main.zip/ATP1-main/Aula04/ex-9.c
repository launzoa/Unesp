/*9) Faça um programa para ler o salário de um funcionário. Em seguida, deve-se calcular e
imprimir o valor do novo salário, sabendo que ele recebeu um aumento de 25%.*/
#include <stdio.h>

int main(){
    float salario, novosalario = 1.25;

    printf("Entre com o salario: ");
    scanf("%f", &salario);

    novosalario *= salario;

    printf("Novo salario e: %.2f", novosalario);

    return 0;
}