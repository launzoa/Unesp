/*4) Faça um programa para ler quatro notas, calcular a média aritmética e imprimir o resultado. */
#include <stdio.h>

int main(){
    float n1,n2,n3,n4,media;
    
    printf("Entre com as 4 notas na mesma linha: ");
    scanf("%f%f%f%f", &n1,&n2,&n3,&n4);
    media = (n1+n2+n3+n4)/4;

    printf("A media e: %.2f", media);

    return 0;
}