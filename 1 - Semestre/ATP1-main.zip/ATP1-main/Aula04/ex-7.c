/*7) Faça um programa para ler um número inteiro e imprimir a sua tabuada.*/
#include <stdio.h>


int main(){
    int n,cont,tabuada;

    printf("Entre com o numero: ");
    scanf("%d", &n);
    
    for(cont = 1; cont<=10; cont++){
        tabuada = cont*n;
        printf("%d x %d = %d\n", n,cont,tabuada);
    }
 
    return 0;
}