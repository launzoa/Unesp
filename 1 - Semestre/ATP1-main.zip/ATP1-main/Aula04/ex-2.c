/*2) Faça um programa que leia um número real e o imprima.*/
#include <stdio.h>

int main(){
    float numero;

    printf("entre com o seu numero: ");
    scanf("%f", &numero);
    printf("O seu numero e: %.2f", numero);
    
    return 0;
}