/*8) Faça um programa que leia o valor de um produto e imprima o valor com desconto, tendo
em vista que o desconto foi de 12%*/
#include <stdio.h>

int main(){
    float valor,desconto = 1.12;

    printf("Entre com o valor: ");
    scanf("%f", &valor);
    desconto *= valor;

    printf("Valor descontado = %.2f", desconto);

    return 0;
}