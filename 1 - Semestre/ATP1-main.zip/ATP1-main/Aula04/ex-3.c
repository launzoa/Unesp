/*3) Faça um programa que pela ao usuário para digitar três valores inteiros e imprima a soma deles.*/
#include <stdio.h>

int main(){
    int n1,n2,n3,soma;

    printf("entre com o primeiro numero: ");
    scanf("%d", &n1);
    printf("entre com o segundo numero: ");
    scanf("%d", &n2);
    printf("entre com o terceiro numero: ");
    scanf("%d", &n3);
    soma = n1+n2+n3;
    printf("O seu numero e: %d", soma);
    
    return 0;
}