/*5) Faça um programa para ler um valor em real e a cotação do dólar. Em seguida, imprima o
valor correspondente em dólares.*/
#include <stdio.h>

int main(){
    float real, dolar = 5.02,conversao;

    printf("Entre com o valor em real: ");
    scanf("%f", &real);
    conversao = real*dolar;

    printf("a conversao em dolar ficou: %.2f", conversao);
    
    return 0;
}