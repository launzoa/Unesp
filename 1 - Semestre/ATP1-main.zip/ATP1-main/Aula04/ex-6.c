/*6) Faça um programa para ler um número inteiro e imprima o seu antecessor e o seu sucessor.*/
#include <stdio.h>

int main(){
    int n,antecessor,sucessor;

    printf("Entre com o numero: ");
    scanf("%d", &n);
    antecessor = n-1;
    sucessor = n+1;

    printf("O antecessor e: %d\n", antecessor);
    printf("O sucessor e: %d\n", sucessor);
    return 0;
}