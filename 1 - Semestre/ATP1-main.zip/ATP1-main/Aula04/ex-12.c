/*12) Para calcular o consumo de um equipamento elétrico, verifique a potência W (Watts) do
equipamento, multiplique essa potência pelo tempo estimado de funcionamento (Horas Por
Dia) e divida por 1000. Desta forma teremos o consumo em kWh do equipamento por dia. Faça
um programa que leia a potência de um aparelho e o tempo de utilização diária em horas.
Apresente o consumo estimado de Watts e kWh por dia, mês e ano. Faça também a leitura do
custo do kWh e indique o gasto mensal estimado do aparelho. Exemplo:
Potência do aparelho: P=3.0 watts;
Tempo de utilização do aparelho: 24.0 horas/dia
Watts/Dia = 72.0
Watts/Mes = 2160.0

2

Watts/Ano = 25920.0
kWh/Dia = 0.072
kWh/Mes = 2.16
kWh/Ano = 25.92
Preço do kWh: R$ 0.27
Gasto mensal é: R$ 0.5832.*/
#include <stdio.h>


int main(){
    float watts,tempo,cw,ckw,preco=0.27;

    printf("Entre com a potencia em watts: ");
    scanf("%f", &watts);

    printf("Entre com o tempo estimado de uso: ");
    scanf("%f", &tempo);

    cw = watts*tempo;
    ckw = (watts*tempo)/1000;
    
    printf("Watts/Dia = %.2f\n", cw);
    printf("Watts/Mes = %.2f\n", cw*30);
    printf("Watts/Ano = %.2f\n", cw*360);
    printf("KWH/Dia = %.3f\n", ckw);
    printf("KWH/Mes = %.3f\n", ckw*30);
    printf("KWH/Ano = %.3f\n", ckw*360);
    printf("Gasto mensal = %.4f\n", ckw*preco*30);
    return 0;
}