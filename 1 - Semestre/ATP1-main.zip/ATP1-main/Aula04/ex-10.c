/*10) A importância de R$ 780.000,00 será dividida entre três ganhadores de um concurso.
Sendo que da quantia total:
 O primeiro ganhador receberá 50%;
 O segundo receberá 30%;
 O terceiro receberá o restante.
Calcule e imprima a quantia ganha por cada um dos ganhadores.*/
#include <stdio.h>

int main(){
    float primeiro=0.5,segundo=0.3,terceiro=0.2,total=780000;
    
    primeiro *= total;
    segundo *= total;
    terceiro *= total;

    printf("Primeiro ganhador: %1.f\n", primeiro);
    printf("Segundo ganhador: %1.f\n", segundo);
    printf("Terceiro ganhador: %1.f\n", terceiro);

    return 0;
}