/*11) Faça um programa para ler duas notas e dois pesos. Em seguida, apresente a média
ponderada dessas notas.*/
#include <stdio.h>

int main(){
    float nota1,nota2,peso1,peso2,media;

    printf("Entre com a primeira e segunda nota na mesma linha: ");
    scanf("%f%f", &nota1,&nota2);

    printf("Entre com a primeiro e segundo peso: ");
    scanf("%f%f", &peso1,&peso2);

    nota1 *= peso1/10;
    nota2 *= peso2/10;
    media = nota1 + nota2;

    printf("A primeira nota vale: %.2f\n", nota1);
    printf("A segunda nota vale: %.2f\n", nota2);
    printf("A media vale: %.2f", media);
    return 0;
}