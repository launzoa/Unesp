/*1) Faça um programa que leia um número inteiro e o imprima.*/
#include <stdio.h>

int main(){
    int numero;

    printf("Entre com o numero: ");
    scanf("%d", &numero);
    printf("O seu numero e: %d", numero);

    return 0;  
}