#include <stdio.h>
#include <math.h>
#include <string.h>
/*Faça um programa para ler um número e apresentar a raiz
quadrada do número*/
int main(){
    int n;

    printf("Entre com o numero: ");
    scanf("%d", &n);

    printf("A raiz quadrada do numero e: %.1lf", sqrt(n));
    return 0;
}