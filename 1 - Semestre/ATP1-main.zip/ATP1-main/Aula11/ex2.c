#include <stdio.h>
#include <math.h>
#include <string.h>
/*Faça um programa para ler um número e apresentar o
resultado das funções: ceil, floor, round e trunc*/
int main(){

    double n;

    printf("Entre com o numero: ");
    scanf("%lf", &n);

    printf("Utilizando a funcao ceil: %.1lf", ceil(n));
    printf("\nUtilizando a funcao floor: %.1lf", floor(n));
    printf("\nUtilizando a funcao round: %.1lf", round(n));
    printf("\nUtilizando a funcao trunc: %.1lf", trunc(n));
    return 0;
}