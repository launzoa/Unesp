#include <stdio.h>
#include <math.h>
#include <string.h>
/*Faça um programa para ler um ângulo em graus e
apresentar o seno e cosseno desse ângulo*/
int main(){
    double n;

    printf("Entre com o angulo: ");
    scanf("%lf", &n);

    printf("O seno: %lf\nO cosseno: %lf", sin((n*3.14159265)/180),cos((n*3.14159265)/180));
    return 0;
}