#include <stdio.h>
#include <math.h>
#include <string.h>
/*Faça um programa para ler a base e o expoente. Em
seguida, deverá apresentar o resultado da potenciação.
Para tanto, use a função pow, conforme segue:
– double pow (double base, double exponent);*/
int main(){
    double base, expoente;

    printf("Entre com a base e o expoente: ");
    scanf("%lf%lf", &base,&expoente);

    printf("A potencializacao fica: %.1lf", pow(base,expoente));
    return 0;
}