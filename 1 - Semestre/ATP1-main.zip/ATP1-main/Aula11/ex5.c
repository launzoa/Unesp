#include <stdio.h>
#include <math.h>
#include <string.h>
/*Faça um programa para ler os valores de a, b e c de uma equação do
2o grau. Em seguida, ele deverá calcular as raízes da equação.
Lembrando que:*/
int main(){
    double a,b,c,delta;
    
    printf("Entre com o valor de a,b e c: ");
    scanf("%lf%lf%lf", &a,&b,&c);

    if(a >= 0){     
        delta = pow(b,2) - 4*a*c; 
        printf("As raizes sao: %.1lf e %.1lf", (-b+sqrt(delta))/2*a, (-b-sqrt(delta))/2*a);
    }
    else{
        printf("Nao existe raiz real");
    }
    return 0;
}