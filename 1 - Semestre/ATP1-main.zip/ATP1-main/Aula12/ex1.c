#include <stdio.h>
#include <math.h>
#include <string.h>
#include <limits.h>
#include<stdbool.h>

/*1) Elabore um programa que faça leitura de vários números inteiros até que se
digite um número negativo. Por fim, o programa tem que retornar o maior e o
menor número lido.*/
int main(){

    int n,maior=INT_MIN,menor=INT_MAX,key=true;

    while(key){
        printf("Entre com o numero: ");
        scanf("%d", &n);

        if(n>=0){
            if(n>=maior){
                maior = n;
            }
            if(n<=menor){
                menor = n;
            }
        }
        else{
            key = false;
        }
    }
    printf("\nMaior valor: %d\nMenor valor: %d", maior,menor);
    return 0;
}