#include <stdio.h>
#include <math.h>
#include <string.h>
/*6) Em Matemática, o número harmônico designado por H(n) define-se como
sendo a soma da série harmônica: H(n) = 1 + 1/2 + 1/3 + 1/4 + ... + 1/n
Faça um programa que leia um valor n inteiro e positivo e apresente o valor de
H(n).*/
int main(){

    int n,cont;
    double h=0;

    printf("Entre com o valor de n: ");
    scanf("%d", &n);
    for(cont=1;cont<=n;cont++){
        h += (float) 1/cont;
    }

    printf("O valor harmonico eh: %.2lf", h);

    return 0;
}