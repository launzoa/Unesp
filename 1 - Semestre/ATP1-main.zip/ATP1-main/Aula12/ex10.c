#include <stdio.h>
#include <math.h>
#include <string.h>
/*10) O cardápio de uma lanchonete é o seguinte:Faça um programa para perguntar quantos itens serão pedidos. Em seguida, deve-
se ler o código dos itens e as quantidades desejadas, calculando e apresentando o

valor a ser pago por item (preço * quantidade). Por fim, o programa exibe o total
geral do pedido. Exemplo de execução:

Informe quantidade de itens deste pedido: 3
Código do item 1: 100
Quantidade do item 1: 2
Subtotal do item 1: 20,00

https://daniloeler.github.io/

Código do item 2: 102
Quantidade do item 2: 1
Subtotal do item 2: 15,00
Código do item 3: 105
Quantidade do item 3: 3
Subtotal do item 3: 9,00
Total Geral: 44,00*/
int main(){

    char cod[3];
    int qntd,n,cont,preco;
    double sub,valor=0;
    int lista[] ={
        10,
        12,
        15,
        11,
        15,
        3
    };

    printf("Entre com a quantidade de itens: ");
    scanf("%d", &n);

    for(cont=1;cont<=n;cont++){
        printf("Codigo do item %d: ", cont);
        scanf("%s", &cod);
        printf("Quantidade do item %d: ", cont);
        scanf("%d", &qntd);
        
        preco = cod[2] - '0';
        sub = qntd*lista[preco];
        valor += sub;

        printf("Subtotal do item %d: %.2lf\n\n", cont,sub);
    }
    printf("O valor total: %lf", valor);
    return 0;
}