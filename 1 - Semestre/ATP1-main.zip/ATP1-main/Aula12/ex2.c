#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdbool.h>
/*2) Faça um programa que leia um conjunto não determinado de valores. A cada
número lido, o programa deverá exibir o quadrado, o cubo e a raiz quadrada.
Finalize a entrada de dados quando o usuário digitar um valor negativo ou zero.*/
int main(){

    int n;
    bool key = true;
    
    while(key){
        printf("Entre com o numero: ");
        scanf("%d", &n);
        if(n>0){
            printf("\nO quadrado do numero: %lf\nO cubo do numero: %lf\nA raiz do numero: %lf\n", pow(n,2), pow(n,3), sqrt(n));
        }
        else{
            key = false;
        }
    }
    return 0;
}