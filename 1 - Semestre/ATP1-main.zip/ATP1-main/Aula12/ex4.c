#include <stdio.h>
#include <math.h>
#include <string.h>
/*4) Faça um programa para ler um valor inteiro e positivo N. Em seguida, deve-se
exibir todos os números de 3 a N que são múltiplos de 3 ou 5.*/
int main(){

    int cont,n;

    printf("Entre com  o valor de n: ");
    scanf("%d", &n);
    for(cont = 3; cont<=n;cont++){
        if((cont % 3) == 0 && (cont % 5) == 0){
            printf("%d e multiplo de 3 e 5!\n", cont);
        }
        else{
            if((cont % 3) == 0){
                printf("%d e multiplo de 3!\n", cont);
            }
            if((cont % 5) == 0){
                printf("%d e multiplo de 5!\n", cont);
            }
        }
    }
    

    return 0;
}