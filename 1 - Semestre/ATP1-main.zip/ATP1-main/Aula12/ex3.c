#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdbool.h>
/*3) Faça um programa que apresente um menu de opções de operações para serem
realizadas entre dois números fornecidos pelo usuário, conforme abaixo. O
programa é finalizado quando o usuário digitar a Opção 5.
MENU
1 - Adição
2 - Subtração
3 - Multiplicação
4 - Divisão
5 - Sair*/
int main(){
    int valor;
    double n1,n2,operacao;
    bool key = true;

    while(key){
        printf("1 - Adicao\n2 - Subtracao\n3 - Multiplicacao\n4 - Divisao\n5 - Sair*\nEntre com o valor: ");
        scanf("%d", &valor);
        
        if(valor <= 4){printf("Entre com o primeiro e segundo numero: ");scanf("%lf%lf", &n1,&n2);}

        switch(valor){
            case 1:
                operacao = n1+n2;
                break;

            case 2:
                operacao = n1-n2;
                break;

            case 3:
                operacao = n1*n2;
                break;

            case 4:
                operacao = n1/n2;
                break;

            case 5:
                key = false;
                operacao = 0;
                break;
            
            default:
                printf("Invalido");
        }
        printf("\nResultado: %.2lf\n", operacao);
    }
    return 0;
}