#include <stdio.h>
#include <math.h>
#include <string.h>
/*5) Faça um programa para ler um inteiro positivo e verificar se ele é primo.
Sabendo que um número primo é aquele que é dividido apenas por um e por ele
mesmo.*/
int main(){

    int n,cont,primo=0;

    printf("Entre com o numero: ");
    scanf("%d", &n);

    for(cont=2;cont<=(int)sqrt(n);cont++){
        if((n % cont) == 0){
            primo++;
        }
    }
    if(primo > 0){
        printf("O numero '%d' nao eh primo!", n);
    }
    else{
        printf("O numero '%d' eh primo!", n);
    }

    return 0;
}