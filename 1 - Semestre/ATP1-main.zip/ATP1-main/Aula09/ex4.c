#include <stdio.h>
#include <math.h>
/*4) Ler 5 valores do usuário e apresentar o menor valor.*/
int main(){

    int n, menor;

    scanf("%d", &n);
    menor = n;
    
    for(int i = 0; i < 4; i++){
        scanf("%d", &n);
        if(menor > n){
            menor = n;
        }
    }

    printf("O maior e: %d", menor);

    return 0;
}