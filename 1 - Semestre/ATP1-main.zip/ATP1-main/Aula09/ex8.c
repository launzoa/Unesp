#include <stdio.h>
#include <math.h>


/*8) Faça um programa para ler a média de N alunos. O valor de N será
fornecido pelo usuário e indica a quantidade de alunos. O seu programa
deve considerar médias entre 0 e 10, isto é, se o usuário digitar uma nota
fora desse intervalo, o programa deve avisar o usuário e aguardar a
inserção de uma nota dentro intervalo indicado.*/
int main(){

    int n, i=1;
    double nota,media = 0;

    scanf("%d", &n);

    while(i <= n){
        printf("Entre com a nota: ");
        scanf("%lf", &nota);
        
        if(nota > 10 || nota < 0){
            printf("Nota invalida\nInsira uma correta a seguir\n");
        }
        else{
            i+=1;
            media += nota;
        }
    }
    media /= n;

    printf("A media e: %.2lf", media);
    return 0;
}