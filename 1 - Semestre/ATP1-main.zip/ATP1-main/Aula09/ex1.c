#include <stdio.h>
#include <math.h>
/*1) Ler cinco valores fornecidos pelo usuário e calcular a média dos valores.*/
int main(){

    int n,valor=0;

    printf("Entre com os valores: ");

    for(int i = 0; i < 5; i++){
        scanf("%d", &n);
        valor += n;
    }

    printf("O valor total e: %d", valor);
    return 0;
}   