#include <stdio.h>
#include <math.h>
/*3) Ler 5 valores do usuário e apresentar o maior valor.*/
int main(){

    int n, maior;

    scanf("%d", &n);
    maior = n;
    
    for(int i = 0; i < 4; i++){
        scanf("%d", &n);
        if(maior < n){
            maior = n;
        }
    }
    printf("O maior e: %d", maior);
    return 0;
}