#include <stdio.h>
#include <math.h>
#include <stdbool.h>

/*6) Ler valores inteiros positivos do usuário até que o número 0 seja
fornecido. Ao final, apresentar a quantidade de números pares e ímpares.*/
int main(){
    bool key = true;
    int n, pr = 0, pa = 0;
    while(key){
        scanf("%d", &n);

        if(n == 0){
            key = false;
        }
        else{
            if((n%2) == 0){
                pr += 1;
            }
            else{
                pa += 1;
            }
        }
    }
    printf("Quantidade de primos: %d\nQuantidade de par: %d", pr,pa);

    return 0;
}