#include <stdio.h>
#include <math.h>
/*9) Faça um programa que receba a idade e a cor dos olhos das pessoas (A
– Azul, P – Preto, V – verde, C – castanho, O – outro). A quantidade de
pessoas deverá ser lida do usuário. Indique ao final a quantidade de
pessoas para cada cor de olhos.*/
int main(){

    int n,a=0,p=0,v=0,c=0,o=0,i;
    char cor;
    printf("Entre com a quantidade: ");
    scanf("%d", &n);

    for(i=1;i<=n;i++){
        fflush(stdin);
        scanf("%c", &cor);

        switch(cor){
            case 'A':
                a+=1;
                break;

             case 'P':
                p+=1;
                break;

             case 'V':
                v+=1;
                break;

             case 'C':
                c+=1;
                break;

             case 'O':
                o+=1;
                break;

            default:
                printf("Cor invalida!\n");
                break;
        }
    }
    printf("A quantidade de Azuis: %d\n A quantidade de Preto: %d\n A quantidade de Verde: %d\n A quantidade de Castanho: %d\n A quantidade de Outros: %d\n", a,p,v,c,o);
    return 0;
}