#include <stdio.h>
#include <math.h>
/*10) Faça um programa que receba a idade, a altura e o peso de N
pessoas. O valor de N será fornecido pelo usuário e indica a quantidade de
pessoas. Após a leitura, indique:
• Quantas pessoas possuem idade superior a 50 anos;
• A média de altura das pessoas com idade entre 10 e 20 anos;
• Percentual de pessoas com peso inferior a 50 quilos.*/
int main(){

    int cont,n,m_i=0,cont_a=0;
    double m_a=0, m_p=0;
    printf("Entre com a quantidade de pessoas entrevistadas: ");
    scanf("%d", &n);

    int idade[n];
    double altura[n], peso[n];

    for(cont=0;cont<n;cont++){
        printf("Entre com o idade: ");
        scanf("%d", &idade[cont]);
        printf("Entre com o altura: ");
        scanf("%lf", &altura[cont]);
        printf("Entre com o peso: ");
        scanf("%lf", &peso[cont]);
        printf("\n");
    }
    
    for(cont=0; cont<n; cont++){
        if(idade[cont] > 50){
            m_i++;
        }
        if(idade[cont] >= 10 && idade[cont] <= 20){
            m_a += altura[cont];
            cont_a++;
        }
        if(peso[cont] < 50){
            m_p ++;
        }
    }
    m_a = m_a/cont_a;
    m_p = (m_p/n)*100;
    printf("\n\nA quantidade de pessoas com idade superior a 50: %d\nA media de altura entre 10-20 anos: %.2lf\nO percentual de pessoas com peso inferior a 50 quilos: %.2lf\n", m_i, m_a, m_p);
    return 0;
}