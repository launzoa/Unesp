#include <stdio.h>
#include <math.h>
/*7) Ler um número e apresentar o seu fatorial. Lembrando que:
n! = 1 x 2 x 3 x 4 x ... x n-1 x n
0! = 1
Exemplo: 5! = 1 x 2 x 3 x 4 x 5 =120*/
int main(){

    int n,fatorial=1, i;

    scanf("%d", &n);

    for(i=1; i<n; i++){
        printf("%d x ", i);
        fatorial *= i;
    }
    fatorial *= i;
    printf("%d = %d", i, fatorial);

    return 0;
}