#include <stdio.h>
#include <math.h>
/*5) Ler 5 valores do usuário e apresentar o maior valor, o menor valor, a
soma e a média dos valores.*/
int main(){
    int menor, maior, n, soma;
    double media;

    scanf("%d", &n);
    maior = n;
    menor = n;
    soma = n;
    for(int i = 0; i < 4; i++){
        scanf("%d", &n);
        soma += n;
        if(menor > n){
            menor = n;
        }
        if(maior < n){
            maior = n;
        }
    }
    media = soma/5.0;
    printf("O maior: %d\nO menor: %d\nA soma: %d\nA media: %.2lf", maior,menor,soma,media);
    return 0;
}