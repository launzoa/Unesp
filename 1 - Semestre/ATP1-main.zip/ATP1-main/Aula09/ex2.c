#include <stdio.h>
#include <math.h>
/*2) Ler a quantidade de valores que serão fornecidos pelo usuário. Em
seguida, fazer a leitura desses valores. Por fim, apresentar a soma e a
média.*/
int main(){

    int n, valor, soma = 0;
    double media = 0;
    printf("Entre com o numero de valores: ");
    scanf("%d", &n);

    for(int i = 0; i < n; i++){
        scanf("%d", &valor);
        soma += valor;
    }

    media = soma/n;

    printf("O valor da soma: %d\n O valor da media %.2lf", soma, media);
    return 0;
}