#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
/*11) Faça um programa para ler uma string e transferir o conteúdo para uma outra
varíavel string (char []).*/
int main(){

    char p1[100];
    int cont, tamanho;

    printf("Entre com a palavra: ");
    scanf("%s", &p1);

    tamanho = strlen(p1);
    char p2[tamanho];

    for(cont=0;cont<=strlen(p1);cont++){
        p2[cont] = p1[cont];
    }
    
    printf("A palavra copiada em outra variavel: %s", p2);
    return 0;

}