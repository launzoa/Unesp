#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
/*13) Palíndromo é uma frase ou palavra que pode ser lida, indiferentemente, da
esquerda para a direita ou vice-versa. Faça um programa para ler uma string e
verificar se o conteúdo é palíndromo. Exemplos: osso, ovo, reter, radar e salas.*/
int main(){
    
    char palavra[100],p1[100],p2[100];
    int cont,j=0;

    printf("Entre com a palavra: ");
    scanf("%s", &palavra);

    for(cont=0;cont<=strlen(palavra)/2;cont++){
        p1[cont] = palavra[cont];
    }

    p1[cont] = '\0';
    
    for(cont=strlen(palavra)-1;cont>=strlen(palavra)/2;cont--){
        p2[j] = palavra[cont];
        j++;
    }
    p2[j] = '\0';

    if(strcmp(p1,p2) == 0){
        printf("Sao equivalentes");
    }
    else{
        printf("Nao sao equivalentes");
    }
    
    return 0;

}