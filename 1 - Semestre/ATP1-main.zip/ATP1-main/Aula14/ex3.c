#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
/*3) Faça um programa para ler uma string e apresentar quantas letras ‘a’, ‘e’, ‘i’,
‘o’ e ‘u’ estão presentes na frase.*/
int main(){
    
    char palavra[100];
    int cont,qntd=0;

    printf("Entre com a palavra: ");
    scanf("%s", &palavra);

    for(cont=0;cont<strlen(palavra);cont++){
        if(palavra[cont] == 'a' || palavra[cont] == 'e' || palavra[cont] == 'o' || palavra[cont] == 'i' || palavra[cont] == 'u'){
            qntd++;
        }
    }

    printf("Estão presentes: %d", qntd);
    return 0;

}