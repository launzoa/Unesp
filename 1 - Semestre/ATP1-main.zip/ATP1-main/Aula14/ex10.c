#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
/*10) Faça um programa para ler duas strings e verificar se elas são iguais, ou seja,
verificar se o conteúdo é o mesmo nas duas frases informadas.*/
int main(){
    
    char p1[100],p2[100];
    int cont;

    printf("Entre com a primeira palavra: ");
    scanf("%s", &p1);
    printf("Entre com a segunda palavra: ");
    scanf("%s", &p2);

    if(strlen(p1) == strlen(p2)){
        for(cont=0;cont<strlen(p1);cont++){
            if(p1[cont] != p2[cont]){
                printf("Nao sao iguais");
                break;
            }
            else{
                if(cont == strlen(p1)-1){
                    printf("Sao iguais");
                }
            }
        }
    }
    else{
        printf("Nao sao iguais");
    }
    return 0;

}