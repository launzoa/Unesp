#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
/*6) Faça um programa que receba uma string e substitua as vogais pelo caractere
‘_’. Em seguida, exibe-se o conteúdo da string.*/
int main(){
    int cont;
    char palavra[100];

    printf("Entre com a palavra: ");
    scanf("%s", palavra);

    for(cont=0; cont<strlen(palavra);cont++){
        if(palavra[cont] == 'a' || palavra[cont] == 'e' || palavra[cont] == 'i' || palavra[cont] == 'o' || palavra[cont] == 'u'){
            palavra[cont] = '_';
        }

    }

    printf("A nova palavra: %s\n", palavra);

    return 0;

}