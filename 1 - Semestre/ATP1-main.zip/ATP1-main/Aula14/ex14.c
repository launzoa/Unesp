#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
/*14) Faça um programa para ler uma string com uma data no formato
“DD/MM/AAAA”. Após a leitura, o programa deve verificar se a data fornecida
pelo usuário está no formato exigido.*/
int main(){

    int dia,mes,ano;
	printf ("Digite o dia: ");
	scanf ("%d", &dia);
	printf ("Digite o mes:");
	scanf ("%d", &mes);
	printf ("Digite o ano:");
	scanf ("%d", &ano);

    if((dia >= 1 && dia <= 31) && (mes >=1 && mes <= 12) && (ano >= 1 && ano <= 2024)){
        if(mes == 2){
            if((ano % 400) == 0){
                if(dia <= 29){
                    printf("Data valida!");
                }
                else{
                    printf("Data invalida!");
                }
            }
            else{
                if(dia <= 28){
                    printf("Data valida!");
                }
                else{
                    printf("Data invalida!");
                }
            }
        }
        else{
            if(mes == 1 || mes == 3 || mes == 5 || mes == 7 || mes == 8 || mes == 10 || mes == 12){
                printf("Data valida!");
            }
            else{
                if(dia <= 30){
                    printf("Data valida!");
                }
                else{
                    printf("Data invalida!");
                }
            }
        }
    }
    else{
        printf("Data invalida!");
    }

    return 0;

}