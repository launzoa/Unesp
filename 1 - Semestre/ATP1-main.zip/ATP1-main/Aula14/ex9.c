#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
/*9) Faça um programa para ler uma string e apresentar o seu tamanho (quantidade
caracteres da frase).*/
int main(){
    
    char palavra[100];
    int qntd=0;

    printf("Entre com a palavra: ");
    scanf("%s", &palavra);

    while(palavra[qntd] != '\0'){
        qntd++;
    }

    printf("O tamanho da string e: %d", qntd);
    return 0;

}