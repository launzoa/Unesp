#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>

/*2) Faça um programa que leia nome, idade, endereço e telefone de uma pessoa e,
seguida, imprima essas informações em uma única linha.*/
int main(){
    
    char nome[100], rua[100];
    int idade, telefone,cep,n;

    printf("Entre com os seus dados:\n");
    printf("Nome: ");
    scanf("%s", &nome);
    printf("Idade: ");
    scanf("%d", &idade);
    printf("Telefone: ");
    scanf("%d", &telefone);
    printf("Rua: ");
    scanf("%s", &rua);
    printf("Cep: ");
    scanf("%d", &cep);
    printf("Numero: ");
    scanf("%d", &n);

    printf("Nome: %s, Idade: %d, Telefone: %d, Rua: %s, CEP: %d, Numero: %d", nome,idade,telefone,rua,cep,n);
    return 0;

}