#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
/*1) Faça um programa que leia uma string e a imprima o seu conteúdo.*/
int main(){
    
    char nome[100];

    printf("Entre com a string: ");
    scanf("%s", &nome);

    printf("O conteudo da string: %s", nome);


    return 0;

}