#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
/*5) Faça um programa para ler uma string e apresentar a quantidade de vogais e
não vogais presentes na frase. Considere que o usuário informará a palavra com
letras minúsculas.*/
int main(){

    int qntd_v=0, qntd_c=0,cont;
    char palavra[100];

    printf("Entre com a palavra: ");
    scanf("%s", palavra);

    for(cont=0; cont<strlen(palavra);cont++){
        if(palavra[cont] == 'a' || palavra[cont] == 'e' || palavra[cont] == 'i' || palavra[cont] == 'o' || palavra[cont] == 'u'){
            qntd_v++;
        }
        else{
            qntd_c++;
        }
    }

    printf("A quantidade de vogais: %d\n", qntd_v);
    printf("A quantidade de consoantes: %d", qntd_c);
    return 0;

}