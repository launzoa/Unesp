#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <stdlib.h>

int main(){
    
    char l1,l2,palavra[100];
    int cont;
    
    
    printf("Entre com a palavra: ");
    scanf("%s", &palavra);
    while (getchar() != '\n');
    
    printf("Entre com a l1: ");
    scanf("%c", &l1);
    
    while (getchar() != '\n');
    printf("Entre com a l2: ");
    scanf("%c", &l2);


    for(cont=0;cont<strlen(palavra);cont++){
        if(palavra[cont] == l1){
            palavra[cont] = l2;
        }   
        
    }

    printf("A nova palavra fica: %s", palavra);

    return 0;

}