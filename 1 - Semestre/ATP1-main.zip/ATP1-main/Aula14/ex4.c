#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
/*4) Faça um programa para ler uma string que represente um padrão binário (0s e
1s). Em seguida, deve-se substituir as ocorrências de um caractere ‘0’ pelo
caractere ‘1’. Por fim, exibir a nova string.*/

int main(){

    char nova_bin[100],bin[100];
    int cont;

    printf("Entre com o binario: ");
    scanf("%s", &bin);

    for(cont=0;cont<strlen(bin);cont++){
        if(bin[cont] == '1'){
            nova_bin[cont] = '0';
        }
        else{
            nova_bin[cont] = '1';
        }
    }

    printf("Novo binario: %s", nova_bin);
    return 0;

}