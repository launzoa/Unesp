#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
/*4) Exibir os 3 primeiros caracteres de uma
string.*/
int main(){
        
    char palavra[100],novapalavra[100];

    printf("Entre com a palavra: ");
    scanf("%s", &palavra);

    strncpy(novapalavra, palavra, 3);

    printf("Palavra antiga: %s\nPalavra nova: %s", palavra,novapalavra);

    return 0;

}