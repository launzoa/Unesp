#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
/*1) Ler o nome, idade e endereço de uma
pessoa. Em seguida, exibir na tela.*/
int main(){
    
    int idade;
    char nome[50], rua[50], cep[20];

    printf("Entre com o nome: ");
    scanf("%s", &nome);
    fflush(stdin);

    printf("Entre com a sua idade: ");
    scanf("%d", &idade);
    fflush(stdin);

    printf("Entre com o seu endereco: ");
    scanf("%s", &rua);
    fflush(stdin);

    printf("Entre com o seu cep: ");
    scanf("%s", &cep);
    fflush(stdin);

    printf("--------------------------------------------------\n");
    printf("Nome: %s", nome);
    printf("\nIdade: %d", idade);
    printf("\nEndereco:\nRua: %s", rua);
    printf("\nCEP: %s", cep);

    return 0;

}