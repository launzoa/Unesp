#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
/*Verificar se uma string contém um
determinado caractere.*/
int main(){
    
    char palavra[100],c;
    int cont;

    printf("Entre com o caractere a analisar: ");
    scanf("%c", &c);
    printf("Entre com a palavra a analisar: ");
    scanf("%s", &palavra);

    for(cont=0;cont<strlen(palavra);cont++){
        if(c == palavra[cont]){
            printf("Esta presente!");
            break;
        }
        else{
            if(cont==strlen(palavra)-1){
                printf("Nao esta presente");
            }
        }
    }



    return 0;

}