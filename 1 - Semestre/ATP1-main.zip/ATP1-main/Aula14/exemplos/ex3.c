#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
/*3) Ler um número binário e substituir o
caractere ‘0’ por um ‘*’.*/
int main(){
        
    char bin[100];
    int cont;

    printf("Entre com o binario: ");
    scanf("%s", &bin);

    for(cont=0;cont<strlen(bin);cont++){
        if(bin[cont] == '0'){
            bin[cont] = '*';
        }
    }

    printf("Resultado: %s",bin);
    return 0;

}