#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
/*5) Exibir os 3 últimos caracteres de uma
string.*/
int main(){
        
    char palavra[100],novapalavra[100] = "", teste[10]="";

    printf("Entre com a palavra: ");
    scanf("%s", &palavra);

    teste[0] = palavra[strlen(palavra)-3];
    teste[1] = palavra[strlen(palavra)-2];
    teste[2] = palavra[strlen(palavra)-1];

    strcpy(novapalavra, teste);

    printf("Palavra antiga: %s\nPalavra nova: %s", palavra,novapalavra);

    return 0;

    return 0;

}