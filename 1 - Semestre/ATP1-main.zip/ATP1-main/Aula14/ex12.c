#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
/*12) A concatenação de strings é uma operação muito comum e que une o conteúdo
de duas strings. Por exemplo: a string “bom” concatenada com a string “dia”
resulta na string “bomdia”. Faça um programa que leia duas strings e efetue a
concatenação da segunda string na primeira. Por exemplo: string1 tem o conteúdo
“bom” e a string2 tem o conteúdo “dia”; após a concatenação a string1 terá o
conteúdo “bomdia”.*/
int main(){
    
    char p1[100],p2[100];
    int cont;

    printf("Entre com a primeira palavra: ");
    scanf("%s", &p1);
    printf("Entre com a segunda palavra: ");
    scanf("%s", &p2);
    
    int j=strlen(p1);

    for(cont=0; cont<strlen(p2); cont++){
        p1[j] = p2[cont];
        j++;
    }
    p1[j] = '\0';
    printf("As duas strings concatenadas fica: %s", p1);
    return 0;

}