#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
/*8) Faça um programa que receba uma palavra e a imprima de trás-para-frente.*/
int main(){
    
    char palavra[100], nova_palavra[100];
    int cont=0,j;

    printf("Entre com a palavra: ");
    scanf("%s", &palavra);
    
    j = strlen(palavra);
    for(j=j-1;j>=0;j--){
        nova_palavra[cont] = palavra[j];
        cont++;
    }
    nova_palavra[cont] = '\0';
    printf("A nova palavra:");
    printf("\n%s", nova_palavra);
    return 0;

}