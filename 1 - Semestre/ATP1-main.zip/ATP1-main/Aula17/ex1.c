#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>


int main(){

    
    return 0;

}