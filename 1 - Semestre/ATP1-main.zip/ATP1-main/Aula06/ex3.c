#include <stdio.h>
/*3) Fazer um programa para ler duas notas de um aluno e verificar se ele foi aprovado ou reprovado.
Para tanto, calcular média simples de duas notas e considerar aprovado se a média for maior ou igual
a cinco.*/
int main(){
    double n1,n2,media;

    printf("Entre com a primeira nota: ");
    scanf("%lf", &n1);
    printf("Entre com a segunda nota: ");
    scanf("%lf", &n2);

    media = (n1+n2)/2;

    if(media >=5){
        printf("Parabens, voce foi aprovado!");
    }
    else{
        printf("Voce foi reprovado! estuda mais burrao");
    }

    return 0;
}