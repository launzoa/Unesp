#include <stdio.h>
/*4) Fazer um programa para ler dois números e verificar se são iguais ou diferentes.*/
int main(){
    int n1,n2;

    printf("Entre com o primeiro numero: ");
    scanf("%d", &n1);
    printf("Entre com o segundo numero: ");
    scanf("%d", &n2);

    if(n1 == n2){
        printf("Ambos os numeros sao iguais!");
    }
    else{
        printf("Ambos os numeros sao diferentes entre si!");
    }

    return 0;
}