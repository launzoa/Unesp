#include <stdio.h>
/*6) Faça um programa para calcular e mostrar o salário reajustado de um funcionário. Se o salário for
até R$ 1000,00 o reajuste será 20%, se entre R$ 1000,00 e R$ 2000,00 o reajuste será de 10%, caso
contrário, não haverá reajuste.*/
int main(){
    double sal,aumento;

    printf("Entre com o salario do funcionario: ");
    scanf("%lf", &sal);
    aumento = sal;

    if(sal < 2000){
        if(sal <= 1000){
            aumento += sal*0.20;
        }
        else{
            aumento += sal*0.10;
        }
        printf("O reajuste do salario ficou: %.2lf", aumento);
    }
    else{
        printf("O salario nao sofreu reajuste!");
    }

    return 0;
}