#include <stdio.h>
/*2) Fazer um programa para ler um número inteiro e verificar se ele é positivo ou negativo.*/
int main(){
    int numero;

    printf("Entre com um numero: ");
    scanf("%d", &numero);

    if(numero > 0){
        printf("O numero '%d' e positivo", numero);
    }
    else{
        if(numero == 0){
            printf("O numero '%d' e neutro", numero);
        }
        else{
            printf("O numero '%d' e negativo", numero);
        }
    }

    return 0;
}