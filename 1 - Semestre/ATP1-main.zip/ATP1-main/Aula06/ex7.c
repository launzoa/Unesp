#include <stdio.h>
/*7) Faça um programa para ler o valor de um produto e classifica-lo. Para tanto, utilize a tabela abaixo.*/
int main(){

    double valor;

    printf("Entre com o valor do produto: ");
    scanf("%lf", &valor);

    if(valor<=500){
        if(valor<100){
            printf("O produto e considerado 'BARATO'");
        }
        else{
            printf("O produto e considerado 'NORMAL'");
        }
    }
    else{
        printf("O produto e considerado 'CARO'");
    }
    
    return 0;
}