#include <stdio.h>
/*7) Faça um programa para ler o número do mês e escrever o nome do mês por extenso. Por
exemplo:
Digite o número do mês: 6
Mês por extenso: junho*/
int main(){

    char *lista[] = {
        NULL,
        "Janeiro",
        "Fevereiro",
        "Marco",
        "Abril",
        "Maio",
        "Junho",
        "Julho",
        "Agosto",
        "Setembro",
        "Outubro",
        "Novembro",
        "Dezembro"
    };

    int n;

    printf("Entre com o numero do mes: ");
    scanf("%d", &n);

    printf("O mes escrito por extenso e: %s", lista[n]);
    return 0;
}