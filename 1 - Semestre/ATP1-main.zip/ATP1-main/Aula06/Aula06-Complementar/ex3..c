#include <stdio.h>
/*3) Faça um programa para ler o salário de um trabalhador e o valor da prestação de um
empréstimo. Se a prestação for maior que 20% do salário, o programa deverá imprimir
“Empréstimo não concedido”; caso contrário imprimirá “Empréstimo concedido”.*/
int main(){

    double sal, emprest;

    printf("Entre com o salario: ");
    scanf("%lf", &sal);
    printf("Entre com o emprestimo: ");
    scanf("%lf", &emprest);

    if(sal*0.20 < emprest){
        printf("Emprestimo nao concedido");
    }
    else{
        printf("Emprestimo concedido");
    }
    
    return 0;
}