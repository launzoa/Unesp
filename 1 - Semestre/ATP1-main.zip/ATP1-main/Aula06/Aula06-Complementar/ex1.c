#include <stdio.h>
/*1) Faça um programa para ler um número inteiro e verificar se este número é par ou ímpar.*/
int main(){
    
    int n;

    printf("Entre com um numero: ");
    scanf("%d", &n);

    if((n%2) == 0){
        printf("O numero e par");
    }
    else{
        printf("O numero e impar");
    }

    return 0;
}