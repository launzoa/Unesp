#include <stdio.h>
/*4) Faça um programa para ler um dígito de 1 a 5. Em seguida, o programa deve apresentar o
nome do dígito por extenso. Exemplo:
Informe um dígito de 1 a 5: 4
Nome por extenso: quatro*/
int main(){
    char *lista[6] = {
        NULL,
        "Um",
        "Dois",
        "Tres",
        "Quatro",
        "Cinco"
    };

    int n;
    
    printf("Entre com o numero: ");
    scanf("%d", &n);
    printf("O valor em extenso fica: %s", lista[n]);

    return 0;
}