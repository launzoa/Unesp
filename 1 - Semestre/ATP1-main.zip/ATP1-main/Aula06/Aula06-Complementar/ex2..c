#include <stdio.h>
/*2) Faça um programa que, dados dois números inteiros, mostre na tela o maior deles, assim
como a diferença existente entre ambos. Por exemplo:
Informe o Primeiro Número: 3
Informe o Segundo Número: 5
O maior é o número 5
A diferença entre eles é 2*/
int main(){

    int n1,n2,dif;

    printf("Entre com o primeiro numero: ");
    scanf("%d", &n1);
    printf("Entre com o segundo numero: ");
    scanf("%d", &n2);

    if(n1>n2){
        printf("O maior numero e: %d\n", n1);
    }
    else{
        printf("O maior numero e: %d\n", n2);
    }

    dif = abs(n1-n2);
    printf("A diferenca entre os numeros e: %d", dif);

    return 0;
}