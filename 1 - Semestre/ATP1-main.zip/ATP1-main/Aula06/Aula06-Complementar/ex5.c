#include <stdio.h>
/*5) Faça um programa que leia duas notas de um aluno, verifique se as notas são válidas e exiba
na tela a média destas notas. Uma nota válida deve ser, obrigatoriamente, um valor entre 0.0 e
10.0. Caso a nota não possua um valor válido, este fato deve ser informado ao usuário e o
programa termina.*/
int main(){
    double n1,n2,media;
    printf("Entre com o primeiro numero: ");
    scanf("%lf", &n1);
    printf("Entre com o segundo numero: ");
    scanf("%lf", &n2);
    

    if (n1 >= 0 && n1 <= 10 && n2 >=0 && n2 <=10){
        media = (n1+n2)/2;
        printf("A media dos dois numeros: %.2lf", media);
    }
    else{
        printf("Algum dos numeros foi considerado invalido!");
    }
    return 0;
}