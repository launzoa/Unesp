#include <stdio.h>
/*6) Faça um programa para ler dois números e o símbolo de uma operação aritmética. Em
seguida, o programa apresenta o resultado da operação. Para tanto, utilize os seguintes
símbolos:
 Soma: +
 Subtração: -
 Divisão: /
 Multiplicação: *
Exemplo:
Digite primeiro número: 5
Digite segundo número: 4
Digite operação: +
Resultado 5 + 4 = 9*/
int main(){
    int n1,n2,resul;
    char op;

    printf("Entre com o primeiro numero: ");
    scanf("%d", &n1);
    printf("A operacao aritmetica e: ");
    scanf("%s", &op);
    printf("o segundo numero e: ");
    scanf("%d", &n2);

    switch(op){
        case '+':
            resul = n1+n2;
            break;

        case '-':
            resul = n1-n2;
            break;

        case '*':
            resul = n1*n2;
            break;

        case '/':
            resul = n1/n2;
            break;

        default:
            printf("Operador indisponivel\n");
    }

    printf("Resultado: %d %c %d = %d", n1,op,n2,resul);

    return 0;
}