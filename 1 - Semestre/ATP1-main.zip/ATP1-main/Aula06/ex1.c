#include <stdio.h>

/*1) Fazer um programa para ler a idade de uma pessoa e verificar se ela é menor ou maior.
*/



int main(){
    int idade;

    printf("Entre com a sua idade: ");
    scanf("%d", &idade);

    if(idade >= 18){
        printf("Infelizmente, voce e de maior!");
    }
    else{
        printf("Felizmente, voce e de menor!");
    }
    return 0;
}