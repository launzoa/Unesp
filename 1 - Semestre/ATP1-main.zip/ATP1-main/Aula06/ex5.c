#include <stdio.h>
/*5) Fazer um programa para ler dois números e apresentar em ordem crescente. Se forem iguais, indicar
que são iguais.*/
int main(){
    int n1,n2;

    printf("Entre com o primeiro numero: ");
    scanf("%d", &n1);
    printf("Entre com o primeiro numero: ");
    scanf("%d", &n2);
    
    if(n1 != n2){
        if(n1>n2){
            printf("A ordem crescente fica: %d, %d\n", n2,n1);
        }
        else{
            printf("A ordem crescente fica: %d, %d\n", n1,n2);
        }
    }
    else{
        printf("Ambos os numeros sao iguais!");
    }
    return 0;
}