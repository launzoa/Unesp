#include <stdio.h>
#include <math.h>
/*2) Faça um programa ler a data de hoje e a data de nascimento de uma pessoa. Em
seguida, o programa deverá apresentar a idade dessa pessoa.*/
int main(){

    int diah = 1, mesh = 4, anoh = 2024, diap, mesp, anop, ano;

    printf("Entre com a data de nascimento da pessoa: ");
    scanf("%d%d%d", &diap, &mesp, &anop);

    ano = anoh - anop;

    if(mesp >= mesh){
        if(mesp == mesh){
            if(diap <= diah){
                printf("A idade e %d anos", ano);
            }
            else{
                printf("A idade e %d anos", (ano-1));
            }
        }
        else{
            printf("A idade e %d anos", (ano-1));
        }
    }
    else{
        printf("A idade e %d anos", ano);
    }

    

    return 0;
}