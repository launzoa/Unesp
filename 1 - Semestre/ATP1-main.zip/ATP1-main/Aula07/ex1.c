#include <stdio.h>
#include <math.h>
/*1) Escreva um programa para ler a idade de um nadador e classifica-lo conforme
a tabela a seguir:*/
int main(){

    int idade;

    printf("Entre com a idade: ");
    scanf("%d", &idade);

    if(idade >= 5){
        if(idade >= 8){
            if(idade >= 11){
                if(idade >= 14){
                    if(idade >= 18){
                        printf("Adulto");
                    }
                    else{
                         printf("Juvenil B");
                    }
                }
                else{
                    printf("Juvenil A");
                }
            }
            else{
                printf("Infantil B");
            }
        }
        else{
            printf("Infantil A");
        }
    }
    else{
        printf("Nao classificado");
    }
    

    return 0;
}