#include <stdio.h>
#include <math.h>
/*6) Leia uma data e determine se ela é válida. Para tanto, verifique se o mês está
entre 1 e 12, e se o dia existe naquele mês. Note que Fevereiro tem 29 dias em
anos bissextos e 28 dias em anos não bissextos.*/
int main(){

    int meses[] = {
        0,
        31,
        28,
        31,
        30,
        31,
        30,
        31,
        31,
        30,
        31,
        30,
        31
    };
    int ano,mes,dia;

    printf("Entre com a data: ");
    scanf("%d%d%d", &dia, &mes, &ano);

    if((ano % 400) == 0 || ((ano % 4) == 0 && (ano % 100) != 0)){
        meses[2] += 1;
    }
    
    if(mes > 12 || mes < 1){
        printf("Mes invalido");
    }
    else{
        if(dia > meses[mes]){
            printf("Dia invalido");
        }
        else{
            printf("Data valida!");
        }
    }
    
    return 0;
}