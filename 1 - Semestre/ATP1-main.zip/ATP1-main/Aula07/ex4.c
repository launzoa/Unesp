#include <stdio.h>
#include <math.h>
/*4) Faça um programa para ler a média de trabalhos e a média de provas de um
aluno. Em seguida, o programa deverá calcular a média final do aluno com base
nas seguintes regras:
 Se o aluno apresentar médias de trabalho e de provas acima de cinco, a
média final será a média aritmética entre as médias de trabalhos e de provas;
 Caso contrário, a média final será a menor das médias obtidas entre
trabalhos e provas.*/
int main(){
    double mediat,mediap,media;

    printf("Entre com a media de trabalhos: ");
    scanf("%lf", &mediat);
    printf("Entre com a media de provas: ");
    scanf("%lf", &mediap);
    
    if(mediat >= 5 && mediap >= 5){
        media = (mediat + mediap)/2;
    }

    else{
        if(mediat >= mediap){
            media = mediap;
        }
        else{
            media = mediat;
        }
    }

    printf("A media final sera: %2.lf ", media);

    return 0;
}