#include <stdio.h>
#include <math.h>
/*Considerando que são fornecidos os valores dos lados (A,
B e C) de um triângulo, faça a classificação com base nos
seguintes conceitos:
– Equilátero: triângulo que tem três lados iguais
– Isósceles: triângulo que tem o comprimento de dois lados iguais
– Escaleno: triângulo que tem os três lados diferentes*/

int main(){

    int a,b,c;

    printf("Entre com os lados do triangulo: ");
    scanf("%d%d%d", &a,&b,&c);

    if(a == b || b == c){
        if(a == b && b == c){
            printf("O triangulo e equilatero");
        }
        else{
            printf("O triangulo e isosceles");
        }
    }
    else{
        printf("O triangulo e escaleno");
    }

    return 0;
}