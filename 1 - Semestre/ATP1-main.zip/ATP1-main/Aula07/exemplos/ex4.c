#include <stdio.h>
#include <math.h>
/*Leia a idade e o tempo de serviço de um trabalhador e
escreva se ele pode ou não se aposentar. As condições
para aposentadoria são:
– Ter pelo menos 65 anos
– Ou ter trabalhado pelo menos 30 anos
– Ou ter pelo menos 60 anos e ter trabalhado pelo menos 25 anos*/
int main(){

    int idade, tempo;

        printf("Entre com a idade do trabalhador: ");
        scanf("%d", &idade);
        printf("Entre com o tempo de trabalho: ");
        scanf("%d", &tempo);

        if(idade >= 65 || tempo >= 30 || (idade >= 60 && tempo >= 25)){
            printf("Apto a aposentar");
        }
        else{
            printf("Inapto a aposentar");
        }

    return 0;
}