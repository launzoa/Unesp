#include <stdio.h>
#include <math.h>
/*Faça um programa para verificar se um determinado
número inteiro é divisível por 3 ou 5, mas não
simultaneamente pelos dois*/
int main(){

    int n;

    printf("Entre com o numero: ");
    scanf("%d", &n);

    if((n % 3) == 0 && (n % 5) == 0){
        printf("O numero %d e divisivel por 3 e por 5", n);
    }
    else{
        if((n % 3) == 0 || (n % 5) == 0){
            if((n % 3) == 0){
                printf("O numero %d e divisivel por 3", n);
            }
            else{
                printf("O numero %d e divisivel por 5", n);
            }
        }
        else{
            printf("O numero %d nao e divisivel por 3 nem por 5", n);
        }
    }

    return 0;
}