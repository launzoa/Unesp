#include <stdio.h>
#include <math.h>
/*3) Faça um programa para ler a média e a frequência de um aluno. Em seguida,
verificar se ele está aprovado, em exame ou reprovado. Para tanto considere as
seguintes regras:
 O aluno é aprovado se estiver com média acima de cinco e frequência acima
de setenta;
 O aluno está em exame se estiver com média entre três e cinco e frequência
acima de setenta;
 O aluno é reprovado se estiver com média abaixo de três ou frequência
abaixo de setenta.
Para este exercício, considere que os valores são corretamente fornecidos pelo
usuário, isto é, a média está entre 0 e 10; e a frequência está em 0 e 100.*/
int main(){
    
    double media,frequencia;

    printf("Entre com a media do aluno: ");
    scanf("%lf", &media);
    printf("Entre com a frequencia do aluno: ");
    scanf("%lf", &frequencia);
    
    if(frequencia >= 70){

        if(media >= 5){
            printf("O aluno esta aprovado");
        }
        else{
            if(media >= 3){
                printf("O aluno esta em exame");
            }
            else{
                printf("O aluno esta reprovado");
            }
        }
    }
    else{
        printf("O aluno esta reprovado");
    }

    return 0;
}