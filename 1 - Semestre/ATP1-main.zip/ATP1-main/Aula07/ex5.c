#include <stdio.h>
#include <math.h>
/*5) Faça um programa para identificar se um determinado ano fornecido pelo
usuário é bissexto. Para tanto, verifique com a seguintes regras:
 Um ano é bissexto se for divisível por 400 ou
 Um ano é bissexto se for divisível por 4 e não for divisível por 100.
Exemplos: 1600, 1988, 1992, 1996, 2000, 2004, 2008, 2012, 2016.*/
int main(){

    int ano;

    printf("Entre com o ano: ");
    scanf("%d", &ano);

    if((ano % 400) == 0 || ((ano % 4) == 0 && (ano % 100) != 0)){
        printf("O ano e bissexto!");
    }
    else{
        printf("O ano nao e bissexto!");
    }
    

    return 0;
}