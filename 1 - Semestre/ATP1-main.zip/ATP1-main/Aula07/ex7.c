#include <stdio.h>
#include <math.h>
/*7) Faça um programa para ler os valores dos lados (A, B e C) de um triângulo e
verificar se podem formar um triângulo. Nessa verificação, considere que o
comprimento de cada lado de um triângulo é menor do que a soma dos outros dois
lados.*/
int main(){

    int a,b,c,somaA,somaB,somaC;

    printf("Entre com os lados do triangulo: ");
    scanf("%d%d%d", &a,&b,&c);

    somaA = b+c;
    somaB = a+c;
    somaC = a+b;

    if(a < somaA && b < somaB && c < somaC){
        printf("A figura pode formar um triangulo!");
    }
    else{
        printf("A figura nao pode formar um triangulo!");
    }

    return 0;
}