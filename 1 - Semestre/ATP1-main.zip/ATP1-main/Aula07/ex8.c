#include <stdio.h>
#include <math.h>
/*8) Escreva um programa para ler três valores inteiros e apresenta-los em ordem
crescente.*/
int main(){

    int n1,n2,n3;

    printf("Entre com tres numeros: ");
    scanf("%d%d%d", &n1,&n2,&n3);

    if(n1 >= n2){
        if(n1 >= n3){
            if(n3 >= n2){
                printf("A ordem crescente ficaria: \n%d\n%d\n%d", n2,n3,n1);
            }
            else{
                printf("A ordem crescente ficaria: \n%d\n%d\n%d", n3,n2,n1);
            }
        }
        else{
            printf("A ordem crescente ficaria: \n%d\n%d\n%d", n2,n1,n3);
        }
    }
    else{
        if(n2 >= n3){
            if(n3 >= n1){
                printf("A ordem crescente ficaria: \n%d\n%d\n%d", n1,n3,n2);
            }
            else{
                printf("A ordem crescente ficaria: \n%d\n%d\n%d", n3,n1,n2);
            }
        }
        else{
            printf("A ordem crescente ficaria: \n%d\n%d\n%d", n1,n2,n3);
        }
    }

    return 0;
}