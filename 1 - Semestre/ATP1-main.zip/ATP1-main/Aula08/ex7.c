#include <stdio.h>
#include <math.h>
/*O cardápio de uma lanchonete é dado pela tabela abaixo. Escreva um programa
que leia o código do item adquirido pelo consumidor e a quantidade, calculando
e mostrando o total a pagar. Não será necessário exibir o produto e o valor,
somente o valor final.*/
int main(){

    int lista[5] = {
        7,
        5,
        10,
        12,
        3
    };
    int cod,qntd,valor;

    printf("Entre com o codigo e a quantidade do produto: ");
    scanf("%d%d", &cod, &qntd);

    switch(cod){
        case 100:
            valor = lista[0]*qntd;
            break;

        case 101:
            valor = lista[1]*qntd;
            break;

        case 102:
            valor = lista[2]*qntd;
            break;

        case 103:
            valor = lista[3]*qntd;
            break;

        case 104:
            valor = lista[4]*qntd;
            break;
        
        default:
            printf("Invalido");
            break;
        }
    
    printf("O valor final e: %d", valor);   
    return 0;
}