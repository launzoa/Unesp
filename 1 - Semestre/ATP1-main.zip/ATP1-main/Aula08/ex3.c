#include <stdio.h>
#include <math.h>
/*3) Faça um programa para ler dois números e o símbolo de uma operação
aritmética. Em seguida, o programa apresenta o resultado da operação. Para tanto,
utilize os seguintes símbolos:
 Soma: +
 Subtração: -
 Divisão: /
 Multiplicação: **/
int main(){

    double n1,n2;
    double calculo;
    char simbolo;

    printf("Entre com os dois numero: ");
    scanf("%lf%lf", &n1,&n2);
    fflush(stdin);
    printf("Entre com o simbolo: ");
    scanf("%c", &simbolo);
    
    switch(simbolo){
        
        case '+':
            calculo = n1+n2;
            break;

        case '-':
            calculo = n1-n2;
            break;

        case '/':
            calculo = n1/n2;
            break;

        case '*':
            calculo = n1*n2;
            break;
        
        default:
            break;
    }
    printf("O calculo vale: %.2lf", calculo);

    return 0;
}