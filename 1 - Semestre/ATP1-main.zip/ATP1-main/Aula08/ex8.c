#include <stdio.h>
#include <math.h>
/*8) Faça um programa para ler uma letra minúscula e escrever se ela é vogal ou
consoante. Considere que o usuário digitará uma letra minúscula.*/
int main(){

    char letra;

    printf("Entre com a letra: ");
    scanf("%c", &letra);

    if(letra == 'a' || letra == 'e' || letra == 'i' || letra == 'o' || letra == 'u'){
        printf("Vogal");
    }
    else{
        printf("Consoante");
    }

    return 0;
}