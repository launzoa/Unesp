#include <stdio.h>
#include <math.h>
/*2) Escreva um programa que leia um inteiro entre 1 e 12 e imprima o mês
correspondente a este número. Isto é, janeiro se 1, fevereiro se 2, e assim por
diante.*/
int main(){
    char *lista[] = {
        "NULL",
        "janeiro",
        "fevereiro",
        "marco",
        "abril",
        "maio",
        "junho",
        "julho",
        "agosto",
        "setembro",
        "outubro",
        "novembro",
        "dezembro"
    };

    int n;

    printf("Entre com o numero do mes: ");
    scanf("%d", &n);

    printf("%s", lista[n]);

    return 0;
}