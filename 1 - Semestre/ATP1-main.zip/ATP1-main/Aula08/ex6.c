#include <stdio.h>
#include <math.h>
/*6) Leia o código de um determinado produto e mostre sua classificação. Utilize a
seguinte tabela como referência:*/
int main(){
    int codigo;

    printf("Entre com o codigo do produto: ");
    scanf("%d", &codigo);
    if(codigo > 6){
        if(codigo >= 8){
            if(codigo > 15){
                printf("Invalido");
            }
            else{
                printf("Limpeza e Utensilios Domesticos");
            }
        }
        else{
            printf("Higiene Pessoal");
        }
    }
    else{
        if(codigo < 5){
            if(codigo < 2){
                if(codigo == 1){
                    printf("Alimento nao-perecivel");
                }
                else{
                    printf("Invalido");
                }
            }
            else{
                printf("Alimento perecível");
            }
        }
        else{
            printf("Vestuario");
        }
    }
    return 0;
}