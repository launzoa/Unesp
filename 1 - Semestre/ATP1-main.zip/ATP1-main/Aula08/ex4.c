#include <stdio.h>
#include <math.h>
/*4) Usando switch, faça um programa para ler dois valores e apresentar para o
usuário o menu de opções conforme abaixo. Em seguida, o programa deverá ler a
opção indicada pelo usuário e efetuar a operação desejada. Adicionalmente, o
programa deve apresentar uma mensagem de erro caso a opção digitada for
inválida.
MENU
1- Somar os dois números
2- Subtrair os dois números
3- Multiplicar os dois números
4- Dividir os dois números (o denominador não pode ser zero)
5- Sair
Digite uma opção:*/

int main(){

    double n1,n2,calculo;
    int valor;

    printf("Entre com os dois numero: ");
    scanf("%lf%lf", &n1,&n2);
    printf("MENU\n1- Somar os dois numeros\n2- Subtrair os dois numeros\n3- Multiplicar os dois numeros\n4- Dividir os dois numeros (o denominador nao pode ser zero)\n5- Sair\nDigite uma opcao:");
    scanf("%d", &valor);
    
    switch(valor){
        
        case 1:
            calculo = n1+n2;
            break;

        case 2:
            calculo = n1-n2;
            break;

        case 3:
            calculo = n1*n2;
            break;

        case 4:
            calculo = n1/n2;
            break;
        
        case 5:
            printf("Erro");
            break;

        default:
            printf("Invalido!");
            break;
    }

    printf("\nO calculo vale: %.2lf", calculo);

    return 0;
}