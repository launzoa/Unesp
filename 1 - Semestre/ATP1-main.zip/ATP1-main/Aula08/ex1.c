#include <stdio.h>
#include <math.h>
/*1) Escreva um programa que leia um inteiro entre 1 e 7 e imprima o dia da semana
correspondente a este número. Isto é, domingo se 1, segunda-feira se 2, e assim
por diante.*/
int main(){

    char *lista[] = {
        "NULL",
        "domingo",
        "segunda-feira",
        "terca-feira",
        "quarta-feira",
        "quinta-feira",
        "sexta-feira",
        "sabado"
    };

    int n;

    printf("Entre com o numero: ");
    scanf("%d", &n);

    printf("%s", lista[n]);

    return 0;
}