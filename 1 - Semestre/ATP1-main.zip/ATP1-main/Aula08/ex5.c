#include <stdio.h>
#include <math.h>
/*5) Escreva um programa para ler a idade de um nadador e classifica-lo conforme
a tabela a seguir:*/

int main(){

    int idade;

    printf("Entre com a idade: ");
    scanf("%d", &idade);

    if(idade >= 5){
        if(idade > 7){
            if(idade > 10){
                if(idade > 13){
                    if(idade > 17){
                        printf("Adulto");
                    }
                    else{
                        printf("Juvenil B");
                    }
                }
                else{
                    printf("Juvenil A");
                }
            }
            else{
                printf("Infantil B");
            }
        }
        else{
            printf("Infantil A");
        }
    }
    else{
        printf("Nao pode competir");
    }

    return 0;
}