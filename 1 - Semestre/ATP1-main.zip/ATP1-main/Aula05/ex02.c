/*2) O custo de uma viagem será estimado pela quantidade gasta combustível. Faça um programa
para calcular o gasto da viagem a partir do consumo do carro (Km/L), o preço do combustível
e a distância a ser percorrida.*/
#include <stdio.h>

int main(){
    float consumo, preco, distancia, gasto;

    printf("Entre com o consumo do carro: ");
    scanf("%f", &consumo);
    printf("Entre com o preco do combustivel: ");
    scanf("%f", &preco);
    printf("Entre com o distancia do carro: ");
    scanf("%f", &distancia);

    gasto = (distancia/consumo)*preco;

    printf("O gasto da viagem e: %.2f", gasto);
    
    return 0;
}