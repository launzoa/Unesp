/*5) Uma empresa contrata um encanador a R$ 30,00 por dia. Faça um programa que solicite o
número de dias trabalhados pelo encanador, sabendo-se que são descontados 8% para imposto
de renda. O programa deverá exibir o valor bruto, o valor do desconto e o valor líquido.*/
#include <stdio.h>

int main(){
    float salario = 30, dias, desconto = 0.08;

    printf("Entre com os dias trabalhados: ");
    scanf("%f", &dias);

    salario *= dias;
    
    printf("O valor bruto: %.2f\n", salario);
    printf("O valor do desconto: %.2f\n", salario*desconto);
    printf("O valor liquido: %.2f", salario*0.92);
    return 0;
}