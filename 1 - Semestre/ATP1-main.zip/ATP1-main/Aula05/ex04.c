/*4) Leia um valor inteiro em segundos, e imprima-o em horas, minutos e segundos.*/
#include <stdio.h>

int main(){
    int segundos,minutos=0,horas=0;

    printf("Valor em segundos: ");
    scanf("%d", &segundos);

    minutos = segundos/60;
    horas = minutos/60;
    minutos = minutos-(horas*60);
    segundos = segundos-(((horas*60)+minutos)*60);
    printf("|Hora(s): %d | Minuto(s): %d | Segundo(s): %d|", horas,minutos,segundos);
    return 0;
}