/*1) Faça um programa para calcular a quantidade de cupons que um cliente recebe ao realizar
uma compra em um supermercado. A partir do valor gasto na compra o programa exibe a
quantidade de cupons, considerando que o cliente recebe um cupom a cada R$ 20,00 em
compras.*/
#include <stdio.h>

int main(){
    float valor;
    int cupom;

    printf("Entre com o valor: ");
    scanf("%f", &valor);

    cupom = valor/20;

    printf("Quantidade de cupons: %d", cupom);

    return 0;
}