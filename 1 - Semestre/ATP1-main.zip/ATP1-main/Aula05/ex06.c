/*6) Leia a altura e o raio de um cilindro circular e imprima o volume do cilindro. O volume de
um cilindro circular e calculado por meio da seguinte equação: V = π ∗ raio2 ∗ altura, onde π =
3.141592.*/
#include <stdio.h>

int main(){
    float altura,raio,volume,pi=3.141592;

    printf("Entre com o raio do cilindro: ");
    scanf("%f", &raio);
    printf("Entre com a altura do cilindro: ");
    scanf("%f", &altura);

    volume = pi * (raio*raio)*altura;

    printf("O volume do cilindro: %.2f", volume);

    return 0;
}