/*3) Três amigos jogaram na loteria. Caso eles ganhem, o prêmio deve ser repartido
proporcionalmente ao valor que cada deu para a realização da aposta. Faça um programa que
leia quanto cada apostador investiu, o valor do prêmio e imprima quanto cada um ganharia do
prêmio com base no valor investido.*/
#include <stdio.h>

int main(){
    float aposta1,aposta2,aposta3,valor,total;

    printf("Entre com o valor do primeiro apostador: ");
    scanf("%f", &aposta1);
    printf("Entre com o valor do segundo apostador: ");
    scanf("%f", &aposta2);
    printf("Entre com o valor do terceiro apostador: ");
    scanf("%f", &aposta3);
    printf("Entre com o valor do premio: ");
    scanf("%f", &valor);

    total = aposta1+aposta2+aposta3;

    printf("O primeiro apostador ganharia: %.1f\n", valor*(aposta1/total));
    printf("O segundo apostador ganharia: %.1f\n", valor*(aposta2/total));
    printf("O terceiro apostador ganharia: %.1f", valor*(aposta3/total));

    return 0;
}