/*7) Faça um programa para ler um número inteiro de 3 dígitos (de 100 a 999). Em seguida, o
programa deverá gerar outro número formado pelos dígitos invertidos do número lido. Lembre
que o operador % calcula o resto da divisão. Exemplo:
Digite um número inteiro entre 100 e 999:
Número lido: 123
Número gerado: 321*/

#include <stdio.h>

int main(){
    int n,um,dois,tres,resto;

    printf("Entre com o numero: ");
    scanf("%d", &n);

    tres = n/100;
    resto = n%100;
    dois = resto/10;
    um = resto%10;

    printf("Numero lido: %d\n", n);
    printf("Numero gerado: %d", um);
    printf("%d", dois);
    printf("%d", tres);
    return 0;
}