#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>

/*9) Faça um programa para ler um número e escreve-lo por extenso. Considere
somente números inteiros entre 0 e 9999. Dica: para facilitar, faça a leitura do
número como string. Exemplos:
Digite um número entre 0 e 9999: 1734
Por extenso: um mil setecentos e trinta e quatro
Digite um número entre 0 e 9999: 234
Por extenso: duzentos e trinta e quatro*/

void Milhares(char valor){
    switch(valor){
        case '1':
            printf("Um mil");
        break;

        case '2':
            printf("Dois mil");
        break;
        
        case '3':
            printf("Tres mil");
        break;

        case '4':
            printf("Quatro mil");
        break;

        case '5':
            printf("Cinco mil");
        break;

        case '6':
            printf("Seis mil");
        break;

        case '7':
            printf("Sete mil");
        break;

        case '8':
            printf("Oito mil");
        break;

        case '9':
            printf("Nove mil");
        break;

        default:
        break;
    }
}

void Centesimo(char valor){
    switch(valor){
        case '1':
            printf("Cento");
        break;

        case '2':
            printf("Duzentos");
        break;
        
        case '3':
            printf("Trezentos");
        break;

        case '4':
            printf("Quatrocentos");
        break;

        case '5':
            printf("Quinhentos");
        break;

        case '6':
            printf("Seiscentos");
        break;

        case '7':
            printf("Setecentos");
        break;

        case '8':
            printf("Oitocentos");
        break;

        case '9':
            printf("Novecentos");
        break;

        default:
        break;
    }
}

void Decimos(char valor){
    switch(valor){
        case '1':
            printf("Dez");
        break;

        case '2':
            printf("Vinte");
        break;
        
        case '3':
            printf("Trinta");
        break;

        case '4':
            printf("Quarenta");
        break;

        case '5':
            printf("Cinquenta");
        break;

        case '6':
            printf("Sessenta");
        break;

        case '7':
            printf("Setenta");
        break;

        case '8':
            printf("Oitotenta");
        break;

        case '9':
            printf("Noventa");
        break;

        default:
        break;
    }
}

void Unidade(char valor){
    switch(valor){
        case '1':
            printf("Um");
        break;

        case '2':
            printf("Dois");
        break;
        
        case '3':
            printf("Tres");
        break;

        case '4':
            printf("Quatro");
        break;

        case '5':
            printf("Cinco");
        break;

        case '6':
            printf("Seis");
        break;

        case '7':
            printf("Sete");
        break;

        case '8':
            printf("Oito");
        break;

        case '9':
            printf("Nove");
        break;

        default:
        break;
    }
}

int main(){
    
    char numero[100];
    int numeroATOI;
    printf("Entre com o numero: ");
    scanf("%s", numero);
    numeroATOI = atoi(numero);
    if(numeroATOI < 1000){
        if(numeroATOI < 100){
            if(numeroATOI < 10){
                Unidade(numero[0]);
            }
            else{
                Decimos(numero[0]);
                printf(" e ");
                Unidade(numero[1]);
            }
        }
        else{
            Centesimo(numero[0]);
            printf(" e ");
            Decimos(numero[1]);
            printf(" e ");
            Unidade(numero[2]);
        }
    }
    else{
        Milhares(numero[0]);
        printf(" ");
        Centesimo(numero[1]);
        printf(" e ");
        Decimos(numero[2]);
        printf(" e ");
        Unidade(numero[3]);
    }

    return 0;

}