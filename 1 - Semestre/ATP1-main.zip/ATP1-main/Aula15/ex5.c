#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
/*5) A concatenação de strings é uma operação muito comum e que une o conteúdo
de duas strings. Por exemplo: a string “bom” concatenada com a string “dia”
resulta na string “bomdia”. Faça um programa que leia duas strings e efetue a
concatenação da segunda string na primeira. Por exemplo: string1 tem o conteúdo
“bom” e a string2 tem o conteúdo “dia”; após a concatenação a string1 terá o
conteúdo “bomdia”.*/
int main(){
    
    char p1[100],p2[100];

    printf("Entre com a primeira palavra: ");
    scanf("%s", p1);

    printf("Entre com a segunda palavra: ");
    scanf("%s", p2);
    
    strcat(p1,p2);

    printf("A concatenacao fica: %s", p1);


    return 0;

}