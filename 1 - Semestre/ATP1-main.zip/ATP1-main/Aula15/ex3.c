#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
/*3) Faça um programa para ler duas strings e verificar se elas são iguais, ou seja,
verificar se o conteúdo é o mesmo nas duas frases informadas.*/
int main(){
    
    char p1[100],p2[100];

    printf("Entre com a primeira string: ");
    scanf("%s", &p1);

    printf("Entre com a segunda string: ");
    scanf("%s", &p2);

    if(strcmp(p1,p2) == 0){
        printf("Sao iguais!");
    }
    else{
        printf("Nao sao iguais");
    }
    return 0;

}