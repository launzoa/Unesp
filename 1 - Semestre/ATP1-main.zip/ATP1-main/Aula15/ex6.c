#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
/*6) Faça uma programa para ler uma palavra a exibi-la com todos os caracteres em
maiúsculo. Note que alguns caracteres podem estar em maiúsculo, quando
digitada pelo usuário. Exemplo:
Digite frase: Papagaio
Frase alterada: PAPAGAIO*/
int main(){
    
    char p1[100];
    int cont;

    printf("Entre com a palavra: ");
    scanf("%s", p1);
    printf("Palavra totalmente em maiusculo: ");
    for(cont=0;cont<strlen(p1);cont++){
        if(p1[cont] > 96){
            printf("%c", p1[cont]-32);
        }
        else{
            printf("%c", p1[cont]);
        }
    }

    return 0;

}