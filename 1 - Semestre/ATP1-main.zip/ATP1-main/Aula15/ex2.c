#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
/*2) Faça um programa para ler uma string e apresentar o seu tamanho (quantidade
caracteres da frase).*/
int main(){
    
    char palavra[100];

    printf("Entre com a string: ");
    scanf("%s", &palavra);

    printf("O tamanho dessa string, e: %d", strlen(palavra));
    return 0;

}