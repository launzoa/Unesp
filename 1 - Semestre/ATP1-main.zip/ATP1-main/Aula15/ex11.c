#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
/*11) Faça um programa para ler uma sequência de caracteres digitados em uma
palavra, sem espaços, e coloca-los em ordem alfabética. Exemplo:
Digite uma palavra (sem espaços): github
Caracteres em ordem alfabética: bghitu*/
int main(){
    
    char palavra[100]="",menor="";
    int cont=0,i,j,indice;

    printf("Entre com a palavra: ");
    scanf("%s", palavra);
    
    for(i=0;i<strlen(palavra)-1;i++){
        
        menor = palavra[i];
        cont++;
        for(j=cont;j<strlen(palavra);j++){
            if(palavra[j] < menor){
                menor = palavra[j];
                indice = j;
            }
        }
        palavra[indice] = palavra[i];
        palavra[i] = menor;
    }
    printf("Caracteres em ordem alfabetica: %s", palavra);

    return 0;

}