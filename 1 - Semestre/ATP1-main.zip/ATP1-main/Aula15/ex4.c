#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
/*4) Faça um programa para ler uma string e transferir o conteúdo para uma outra
varíavel string (char []).*/
int main(){
    
    char p1[100],p2[100] = "";

    printf("Entre com a palavra: ");
    scanf("%s", p1);
    
    strcpy(p2,p1);
    
    printf("Palavra transferida para outra variavel: %s", p2);   

    return 0;

}