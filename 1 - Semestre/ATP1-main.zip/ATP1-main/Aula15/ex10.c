#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
/*10) É muito comum o uso de arquivos texto para armazenamento de dados no
formado CSV (comma-separated values)—em português, valores separados por
vírgula. Faça um programa para ler uma frase que contenha números separados
por vírgula. Em seguida, exiba a soma desses números. Considere somente
números inteiros. Dica: utilizar a função atoi para converter os números para
inteiro. Exemplo:
Frase: 10, 15, 1, 5, 4
Soma: 35*/
int main(){
    
    char numeros[100],n[100];
    int cont,soma=0,i=0;
    printf("Entre com a frase: ");
    fgets(numeros, 100, stdin);

    for(cont=0;cont<strlen(numeros);cont++){
        if(numeros[cont] == ',' || numeros[cont] == ' '){
            n[i] = '\0';
            soma += atoi(n);
            i = 0;
            n[0] = '\0';
        }
        else{
            n[i] = numeros[cont];
            i++;
        }
    }
    n[i] = '\0';
    soma += atoi(n);

    printf("A soma total e: %d", soma);

    return 0;

}