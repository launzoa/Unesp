#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
/*1) Faça um programa que leia nome, idade, endereço e telefone de uma pessoa e,
seguida, imprima essas informações em uma única linha. Utilizar o getchar ao
invés do fflush.*/
int main(){
    
    char nome[100],endereco[100];
    int idade,telefone;

    printf("Entre com as suas informacoes: ");

    
    printf("\nNome: ");
    scanf("%s", &nome);


    printf("Endereco: ");
    scanf("%s", &endereco);


    printf("Idade: ");
    scanf("%d", &idade);

    printf("Telefone: ");
    scanf("%d", &telefone);

    printf("As suas informacoes: \n");
    printf("Nome: %s, Endereco: %s, Idade: %d, Telefone: %d", nome,endereco,idade,telefone);
    return 0;

}