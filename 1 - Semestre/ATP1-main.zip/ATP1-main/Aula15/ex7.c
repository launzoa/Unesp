#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
/*7) Faça um programa para ler uma frase e ajustá-la de modo que a primeira letra
de cada palavra esteja em maiúsculo e as demais em minúsculo. Exemplo:
Digite uma frase: Hoje eu vou Programar muito
Frase alterada: Hoje Eu Vou Programar Muito*/
int main(){
   
    char palavra[100];
    int cont,comeco=1;

    printf("Entre com a frase:");
    fgets(palavra, 100, stdin);

    for(cont=0;cont<strlen(palavra);cont++){
        if(palavra[cont] == ' '){
            comeco = 1;
            printf(" ");
        }
        else{
            if(comeco == 1){
                if(palavra[cont] > 96){
                    printf("%c", palavra[cont]-32);
                }
                else{
                    printf("%c", palavra[cont]);
                }
                comeco = 0;
            }
            else{
                if(palavra[cont] > 96){
                    printf("%c", palavra[cont]);
                }
                else{
                    printf("%c", palavra[cont]+32);
                }
            }
        }
    }
    
    return 0;

}