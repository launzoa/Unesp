#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
/*8) Faça um programa para ler uma quantidade de palavras informadas pelo
usuário e indicar qual seria a primeira e a última considerando a ordem alfabética.
Exemplo:
Informe quantas palavras irá digitar: 5
Camelo
Abacate
Rato
Computador
Laranja
Primeira: Abacate
Última: Rato*/
int main(){
    
    char palavra[100],menor[100]="",maior[100]="";
    int cont,qntd;

    printf("Quantas palavras ira digitar: ");
    scanf("%d", &qntd);

    scanf("%s", palavra);
    strcpy(maior,palavra);
    strcpy(menor,palavra);

    for(cont=0;cont<qntd-1;cont++){
        scanf("%s", palavra);
        
        if(strcmp(palavra,maior) > 0){
            strcpy(maior,palavra);
        }
        else{
            if(strcmp(palavra,menor) < 0){
                strcpy(menor,palavra);
            }
        }
    }
    
    printf("Primeira: %s\nUltima: %s", menor,maior);
    return 0;

}