#include <stdio.h>
#include <math.h>
#include <limits.h>
/*3) Ler 5 valores do usuário e apresentar o maior valor, o menor valor, a
soma e a média dos valores.*/
int main(){

    int n,cont=0,maior=INT_MIN,menor=INT_MAX, valor;
    double soma=0;

    printf("Entre com a quantidade de pessoas: ");
    scanf("%d", &n);

    do{
        printf("Entre com o valor: ");
        scanf("%d", &valor);
        if(valor < menor){
            menor = valor;
        }
        if(valor > maior){
            maior = valor;
        }
        soma += valor;
        cont++;
    }while(cont<n);

    printf("O maior: %d\nO menor: %d\nA soma dos valores: %.2lf\nA media dos valores: %.2lf", maior,menor,soma,soma/n);

    return 0;
}