#include <stdio.h>
#include <math.h>
/*6) Ler cinco valores fornecidos pelo usuário e calcular a média dos valores.*/
int main(){
    int cont;
    double valor,media=0;

    for(cont=0;cont<5;cont++){
        printf("Entre com o valor: ");
        scanf("%lf", &valor);
        media+=valor;
    }

    printf("A media e: %.2lf", media/5.0);

    return 0;
}