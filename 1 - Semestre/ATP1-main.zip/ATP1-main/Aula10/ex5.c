#include <stdio.h>
#include <math.h>
/*5) Ler um número e apresentar o seu fatorial. Lembrando que:
n! = 1 x 2 x 3 x 4 x ... x n-1 x n
0! = 1
Exemplo: 5! = 1 x 2 x 3 x 4 x 5 = 120*/
int main(){
    int n,cont=1;

    printf("Entre com o numero: ");
    scanf("%d", &n);

    int fatorial=n;
    
    do{
        fatorial *= cont;
        cont++;
    }while(cont!=n);

    printf("O fatorial de %d e: %d", n, fatorial);
    return 0;
}