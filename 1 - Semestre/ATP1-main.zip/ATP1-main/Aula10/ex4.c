#include <stdio.h>
#include <math.h>
/*4) Ler valores inteiros positivos do usuário até que o número 0 seja
fornecido. Ao final, apresentar a quantidade de números pares e ímpares.*/
int main(){
    
    int n=1,par=0,impar=0;

    do{
      printf("Entre com o numero: ");
      scanf("%d", &n);

      if((n%2)==0 && n!=0){
        par++;
      } 
      else{
        impar++;
      } 
    }while(n!=0);

    printf("A quantidade de numeros pares: %d\nA quantidade de numeros impares: %d\n", par,impar);
    return 0;
}