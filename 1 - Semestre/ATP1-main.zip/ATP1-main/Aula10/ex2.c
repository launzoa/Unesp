#include <stdio.h>
#include <math.h>
/*2) Ler quantos valores serão fornecidos pelo usuário. Em seguida, fazer a
leitura desses valores. Por fim, apresentar a soma e a média.*/
int main(){

    int n,cont=0;
    double valor, soma=0;

    printf("Entre com a quantidade de pessoas: ");
    scanf("%d", &n);

    do{
        printf("Entre com o valor: ");
        scanf("%lf", &valor);

        soma += valor;
        cont++;
    }while(cont<n);

    printf("A soma dos valores: %.1lf\nA media dos valores: %.2lf", soma,soma/n);

    return 0;
}