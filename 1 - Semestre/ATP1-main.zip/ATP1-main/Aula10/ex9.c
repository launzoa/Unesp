#include <stdio.h>
#include <math.h>
/*9) Ler valores inteiros positivos do usuário até que o número 0 seja
fornecido. Ao final, apresentar a quantidade de números pares e ímpares.*/
int main(){
    int cont, n,par=0,impar=0;

    for(cont=1;cont<=2;cont++){
        cont = 1;

        printf("Entre com o numero: ");
        scanf("%d", &n);

        if(n==0){
            cont = 2;
        }
        else{
            if((n%2) == 0){
                par++;
            }
            else{
                impar++;
            }
        }
    }
    printf("\nQuantidade de numeros pares: %d\n", par);
    printf("Quantidade de numeros impares: %d", impar);
    return 0;
}