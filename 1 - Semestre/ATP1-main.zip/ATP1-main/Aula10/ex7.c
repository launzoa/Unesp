#include <stdio.h>
#include <math.h>
/*7) Ler quantos valores serão fornecidos pelo usuário. Em seguida, fazer a
leitura desses valores. Por fim, apresentar a soma e a média.*/
int main(){

    int n,cont;
    double valor, soma=0;

    printf("Entre com a quantidade de pessoas: ");
    scanf("%d", &n);

    for(cont=0;cont<n;cont++){
        printf("Entre com o valor: ");
        scanf("%lf", &valor);

        soma += valor;

    }

    printf("A soma dos valores: %.1lf\nA media dos valores: %.2lf", soma,soma/n);

    return 0;
}