#include <stdio.h>
#include <math.h>
/*10) Ler um número e apresentar o seu fatorial. Lembrando que:
n! = 1 x 2 x 3 x 4 x ... x n-1 x n
0! = 1
Exemplo: 5! = 1 x 2 x 3 x 4 x 5 =120*/
int main(){
    int n,cont,fatorial=1;
    
    printf("Entre com o numero: ");
    scanf("%d", &n);

    for(cont=1;cont<=n;cont++){
        fatorial *= cont;
    }
    printf("O numero %d em fatorial fica: %d", n, fatorial);
    return 0;
}