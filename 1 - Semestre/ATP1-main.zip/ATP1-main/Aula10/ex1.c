#include <stdio.h>
#include <math.h>
/*1) Ler cinco valores fornecidos pelo usuário e calcular a média dos valores.*/
int main(){
    int cont=0;
    double valor,media=0;
    do{
        printf("Entre com o valor");
        scanf("%lf", &valor);
        media+=valor;
        cont++;
    }while(cont<5);    

    printf("A media e: %.2lf", media/5.0);
    return 0;
}